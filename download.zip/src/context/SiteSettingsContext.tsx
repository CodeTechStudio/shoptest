
"use client";

import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';

const DEFAULT_SITE_NAME = "CalcVerse";
const DEFAULT_COPYRIGHT_TEXT = `© {{year}} ${DEFAULT_SITE_NAME}. All rights reserved.`;

// PRD Colors translated to HSL strings for CSS variables
const PRD_PRIMARY_COLOR_HSL = "262 52% 50%";    // Default: #673AB7
const PRD_BACKGROUND_COLOR_HSL = "0 0% 96%";   // Default: #F5F5F5
const PRD_ACCENT_COLOR_HSL = "187 100% 42%";  // Default: #00BCD4

interface SiteSettingsContextType {
  siteName: string;
  setSiteName: (name: string) => void;
  copyrightText: string;
  setCopyrightText: (text: string) => void;
  primaryColor: string;
  setPrimaryColor: (hslString: string) => void;
  backgroundColor: string;
  setBackgroundColor: (hslString: string) => void;
  accentColor: string;
  setAccentColor: (hslString: string) => void;
  isLoading: boolean;
}

const SiteSettingsContext = createContext<SiteSettingsContextType | undefined>(undefined);

const applyCssVariable = (variableName: string, value: string) => {
  if (typeof document !== 'undefined') {
    document.documentElement.style.setProperty(variableName, value);
  }
};

const deriveSecondaryColor = (primaryHsl: string, forDarkMode: boolean): string => {
    const parts = primaryHsl.split(" ").map(v => v.replace('%',''));
    if (parts.length < 3) return forDarkMode ? "262 46% 30%" : "262 52% 90%"; // Default secondaries

    const h = parseFloat(parts[0]);
    const s = parseFloat(parts[1]);
    let l = parseFloat(parts[2]);

    if (isNaN(h) || isNaN(s) || isNaN(l)) return forDarkMode ? "262 46% 30%" : "262 52% 90%";

    const secondaryS = Math.max(0, s - 10); // Slightly less saturation
    let secondaryL;

    if (forDarkMode) {
      // For dark mode, secondary is usually darker than primary
      secondaryL = Math.max(0, l - 20); 
    } else {
      // For light mode, secondary is usually lighter
      secondaryL = Math.min(100, l + 25);
    }
    return `${h} ${secondaryS}% ${secondaryL}%`;
};


export const SiteSettingsProvider = ({ children }: { children: ReactNode }) => {
  const [siteName, setSiteNameState] = useState(DEFAULT_SITE_NAME);
  const [copyrightText, setCopyrightTextState] = useState(DEFAULT_COPYRIGHT_TEXT);
  const [primaryColor, setPrimaryColorState] = useState(PRD_PRIMARY_COLOR_HSL);
  const [backgroundColor, setBackgroundColorState] = useState(PRD_BACKGROUND_COLOR_HSL);
  const [accentColor, setAccentColorState] = useState(PRD_ACCENT_COLOR_HSL);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let loadedSiteName = DEFAULT_SITE_NAME;
    let loadedCopyrightText = DEFAULT_COPYRIGHT_TEXT;
    let loadedPrimaryColor = PRD_PRIMARY_COLOR_HSL;
    let loadedBackgroundColor = PRD_BACKGROUND_COLOR_HSL;
    let loadedAccentColor = PRD_ACCENT_COLOR_HSL;

    if (typeof window !== 'undefined') {
        try {
        const storedSiteName = localStorage.getItem('calcverseSiteName');
        if (storedSiteName) loadedSiteName = storedSiteName;

        const storedCopyright = localStorage.getItem('calcverseCopyrightText');
        if (storedCopyright) loadedCopyrightText = storedCopyright;

        const storedPrimaryColor = localStorage.getItem('calcversePrimaryColor');
        if (storedPrimaryColor) loadedPrimaryColor = storedPrimaryColor;

        const storedBackgroundColor = localStorage.getItem('calcverseBackgroundColor');
        if (storedBackgroundColor) loadedBackgroundColor = storedBackgroundColor;

        const storedAccentColor = localStorage.getItem('calcverseAccentColor');
        if (storedAccentColor) loadedAccentColor = storedAccentColor;

        } catch (error) {
        console.error("Error loading site settings from localStorage. Using defaults.", error);
        }
    }

    setSiteNameState(loadedSiteName);
    setCopyrightTextState(loadedCopyrightText);
    setPrimaryColorState(loadedPrimaryColor);
    setBackgroundColorState(loadedBackgroundColor);
    setAccentColorState(loadedAccentColor);
    
    // Apply initial colors (important for first load & SSR potentially)
    // This needs to be careful with SSR, but for client-side context, this is okay.
    if (typeof document !== 'undefined') {
        applyCssVariable('--primary', loadedPrimaryColor);
        applyCssVariable('--ring', loadedPrimaryColor); 
        applyCssVariable('--secondary', deriveSecondaryColor(loadedPrimaryColor, document.documentElement.classList.contains('dark')));
        
        applyCssVariable('--background', loadedBackgroundColor);
        applyCssVariable('--accent', loadedAccentColor);

        // Adjust card/popover for light/dark mode based on the main background
        // This is a simplified approach. More complex themes might need distinct variables.
        if (document.documentElement.classList.contains('dark')) {
            // Dark mode card/popover can be derived or use defaults from globals.css
            // For now, let's ensure dark mode variables are not overridden by light background
            const darkBgParts = loadedBackgroundColor.split(" ").map(v => v.replace('%',''));
            if (darkBgParts.length === 3) {
                const darkL = parseFloat(darkBgParts[2]);
                if (darkL > 50) { // if the loaded BG is light, don't apply it to dark mode cards
                    // use default dark card/popover from globals.css by not setting them here
                } else {
                    applyCssVariable('--card', loadedBackgroundColor); 
                    applyCssVariable('--popover', loadedBackgroundColor);
                }
            }
        } else {
             applyCssVariable('--card', loadedBackgroundColor); 
             applyCssVariable('--popover', loadedBackgroundColor);
        }
    }
    
    setIsLoading(false);
  }, []);

  const setSiteName = useCallback((name: string) => {
    setSiteNameState(name);
    if (typeof window !== 'undefined') localStorage.setItem('calcverseSiteName', name);
  }, []);

  const setCopyrightText = useCallback((text: string) => {
    setCopyrightTextState(text);
    if (typeof window !== 'undefined') localStorage.setItem('calcverseCopyrightText', text);
  }, []);

  const setPrimaryColor = useCallback((hslString: string) => {
    setPrimaryColorState(hslString);
    if (typeof window !== 'undefined') {
        localStorage.setItem('calcversePrimaryColor', hslString);
        applyCssVariable('--primary', hslString);
        applyCssVariable('--ring', hslString); 
        applyCssVariable('--secondary', deriveSecondaryColor(hslString, document.documentElement.classList.contains('dark')));
    }
  }, []);

  const setBackgroundColor = useCallback((hslString: string) => {
    setBackgroundColorState(hslString);
    if (typeof window !== 'undefined') {
        localStorage.setItem('calcverseBackgroundColor', hslString);
        applyCssVariable('--background', hslString);
        // Re-evaluate card/popover for light/dark
        if (document.documentElement.classList.contains('dark')) {
             const darkBgParts = hslString.split(" ").map(v => v.replace('%',''));
            if (darkBgParts.length === 3) {
                const darkL = parseFloat(darkBgParts[2]);
                 if (darkL < 50) { // Only apply if it's a dark color
                    applyCssVariable('--card', hslString); 
                    applyCssVariable('--popover', hslString);
                 } else {
                    // If user tries to set a light background while in dark mode,
                    // we might want to reset card/popover to dark defaults or handle differently.
                    // For now, we'll only set it if it's a dark color.
                    // Let's use a darker shade for card/popover if background is too light for dark mode
                     applyCssVariable('--card', `hsl(${darkBgParts[0]} ${darkBgParts[1]}% ${Math.max(0, darkL - 70)}%)`);
                     applyCssVariable('--popover', `hsl(${darkBgParts[0]} ${darkBgParts[1]}% ${Math.max(0, darkL - 70)}%)`);
                 }
            }
        } else {
            applyCssVariable('--card', hslString); 
            applyCssVariable('--popover', hslString);
        }
    }
  }, []);

  const setAccentColor = useCallback((hslString: string) => {
    setAccentColorState(hslString);
    if (typeof window !== 'undefined') {
        localStorage.setItem('calcverseAccentColor', hslString);
        applyCssVariable('--accent', hslString);
    }
  }, []);

  // Listen to theme changes to re-calculate secondary color
  useEffect(() => {
    if (typeof window === 'undefined' || isLoading) return;

    const observer = new MutationObserver((mutationsList) => {
      for (const mutation of mutationsList) {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
          applyCssVariable('--secondary', deriveSecondaryColor(primaryColor, document.documentElement.classList.contains('dark')));
          // Also re-apply background dependent card/popover
          const currentBg = document.documentElement.style.getPropertyValue('--background').trim();
          if (currentBg) {
            if (document.documentElement.classList.contains('dark')) {
                const darkBgParts = currentBg.split(" ").map(v => v.replace('%',''));
                if (darkBgParts.length === 3) {
                    const darkL = parseFloat(darkBgParts[2]);
                    if (darkL < 50) {
                        applyCssVariable('--card', currentBg); 
                        applyCssVariable('--popover', currentBg);
                    } else {
                         applyCssVariable('--card', `hsl(${darkBgParts[0]} ${darkBgParts[1]}% ${Math.max(0, darkL - 70)}%)`);
                         applyCssVariable('--popover', `hsl(${darkBgParts[0]} ${darkBgParts[1]}% ${Math.max(0, darkL - 70)}%)`);
                    }
                }
            } else {
                applyCssVariable('--card', currentBg); 
                applyCssVariable('--popover', currentBg);
            }
          }
        }
      }
    });

    observer.observe(document.documentElement, { attributes: true });
    return () => observer.disconnect();
  }, [primaryColor, isLoading, backgroundColor]);


  return (
    <SiteSettingsContext.Provider value={{
      siteName, setSiteName,
      copyrightText, setCopyrightText,
      primaryColor, setPrimaryColor,
      backgroundColor, setBackgroundColor,
      accentColor, setAccentColor,
      isLoading
    }}>
      {children}
    </SiteSettingsContext.Provider>
  );
};

export default SiteSettingsContext;

    