
"use client";

import type { User } from '@/types/auth';
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { useToast } from '@/hooks/use-toast';

interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  login: (username: string, pass: string) => boolean; // pass is for simulation
  logout: () => void;
  register: (username: string, pass: string) => boolean; // pass is for simulation
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true); // To prevent flash of unauth content
  const { toast } = useToast();

  useEffect(() => {
    // Check localStorage for persisted auth state
    try {
      const storedUser = localStorage.getItem('calcverseUser');
      if (storedUser) {
        const parsedUser: User = JSON.parse(storedUser);
        setUser(parsedUser);
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.error("Error reading auth state from localStorage", error);
      localStorage.removeItem('calcverseUser'); // Clear potentially corrupted data
    }
    setIsLoading(false);
  }, []);

  const login = (username: string, pass: string): boolean => {
    // SIMULATED LOGIN: In a real app, call an API
    // For now, just check if the user was "registered" (i.e., username exists in localStorage mock)
    try {
      const storedUser = localStorage.getItem('calcverseUser');
      if (storedUser) {
        const parsedUser: User = JSON.parse(storedUser);
        // In a real app, you'd also verify the password hash
        if (parsedUser.username === username) {
          setUser(parsedUser);
          setIsAuthenticated(true);
          toast({ title: "Login Successful", description: `Welcome back, ${username}!` });
          return true;
        }
      }
      toast({ title: "Login Failed", description: "Invalid username or password.", variant: "destructive" });
      return false;
    } catch (error) {
        toast({ title: "Login Error", description: "An unexpected error occurred.", variant: "destructive" });
        return false;
    }
  };

  const logout = () => {
    try {
      localStorage.removeItem('calcverseUser');
    } catch (error) {
        console.error("Error removing auth state from localStorage", error);
    }
    setUser(null);
    setIsAuthenticated(false);
    toast({ title: "Logged Out", description: "You have been successfully logged out." });
  };

  const register = (username: string, pass: string): boolean => {
    // SIMULATED REGISTRATION: In a real app, call an API to create user
    // For now, just store it in localStorage and log them in.
    // Basic validation:
    if (username.trim().length < 3 || pass.trim().length < 6) {
        toast({ title: "Registration Failed", description: "Username must be at least 3 characters and password at least 6 characters.", variant: "destructive"});
        return false;
    }
    try {
      const newUser: User = { id: Date.now().toString(), username }; // Simple ID
      localStorage.setItem('calcverseUser', JSON.stringify(newUser));
      setUser(newUser);
      setIsAuthenticated(true);
      toast({ title: "Registration Successful", description: `Welcome, ${username}! You are now logged in.` });
      return true;
    } catch (error) {
      toast({ title: "Registration Failed", description: "Could not create account.", variant: "destructive" });
      return false;
    }
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout, register, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
