import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Header } from '@/components/common/Header';
import { Footer } from '@/components/common/Footer';
import { CATEGORIES, getCalculatorsByCategory, ALL_CALCULATORS } from '@/data/calculators';
import type { Calculator, Category } from '@/types/calculators';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';

export async function generateStaticParams() {
  return CATEGORIES.map((category) => ({
    slug: category.slug,
  }));
}

interface CategoryPageProps {
  params: {
    slug: string;
  };
}

export default function CategoryPage({ params }: CategoryPageProps) {
  const category = CATEGORIES.find(cat => cat.slug === params.slug);

  if (!category) {
    notFound();
  }

  const calculatorsInCategory = getCalculatorsByCategory(category.slug);

  return (
    <>
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <Button variant="outline" asChild>
            <Link href="/" className="text-primary hover:text-primary/80">
              <ChevronLeft className="mr-2 h-4 w-4" /> Back to Home
            </Link>
          </Button>
        </div>

        <header className="mb-12 text-center">
          <category.icon className="h-16 w-16 text-primary mx-auto mb-4" aria-hidden="true" />
          <h1 className="font-headline text-4xl md:text-5xl font-bold text-primary">{category.name}</h1>
          {category.description && (
            <p className="mt-2 text-lg text-muted-foreground max-w-2xl mx-auto">{category.description}</p>
          )}
        </header>

        {calculatorsInCategory.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {calculatorsInCategory.map((calculator: Calculator) => (
              <Card key={calculator.id} className="flex flex-col shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1">
                <CardHeader>
                  <div className="flex items-center space-x-3 mb-2">
                    <calculator.icon className="h-8 w-8 text-primary" aria-hidden="true" />
                    <CardTitle className="text-2xl font-semibold text-foreground">{calculator.name}</CardTitle>
                  </div>
                  <CardDescription className="h-12 overflow-hidden">{calculator.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  {/* Can add more details here if needed */}
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    <Link href={`/calculators/${calculator.slug}`}>Use Now</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-xl text-muted-foreground">No calculators found in this category yet.</p>
            <p className="mt-2">Check back soon or explore other categories!</p>
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}
