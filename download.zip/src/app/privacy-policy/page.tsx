
import { Header } from "@/components/common/Header";
import { Footer } from "@/components/common/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function PrivacyPolicyPage() {
  return (
    <>
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto shadow-lg">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-primary">Privacy Policy</CardTitle>
            <CardDescription>Last updated: {new Date().toLocaleDateString()}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 text-muted-foreground">
            <p>Welcome to CalcVerse! This Privacy Policy outlines how we handle your information when you use our website and services. Since this is a prototype application, our data handling practices are minimal and primarily for demonstration purposes.</p>
            
            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">1. Information We Collect (Simulated)</h2>
              <p>For the purpose of this prototype, if you choose to "register" an account, we simulate the collection of:</p>
              <ul className="list-disc list-inside ml-4 space-y-1 mt-2">
                <li><strong>Username:</strong> The username you provide during mock registration.</li>
                <li><strong>Password:</strong> The password you provide (stored in browser's localStorage for this simulation only - NOT a secure practice for real applications).</li>
              </ul>
              <p className="mt-2">We do not collect any other personal information. Calculator inputs and results are processed client-side and are not stored by us.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">2. How We Use Your Information (Simulated)</h2>
              <p>The information collected during the mock registration is used solely to:</p>
              <ul className="list-disc list-inside ml-4 space-y-1 mt-2">
                <li>Simulate a user login session.</li>
                <li>Demonstrate features that would require authentication in a real application.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">3. Data Storage (Simulated)</h2>
              <p>Your mock registration details (username and a representation of your password) are stored in your web browser's `localStorage`. This data is not transmitted to any server and is cleared when you "logout" or clear your browser's site data.</p>
              <p className="font-semibold mt-2">Important: This localStorage approach is for prototyping only and is not secure for real user credentials.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">4. Third-Party Services</h2>
              <p>CalcVerse does not integrate with any third-party services that collect personal information for this prototype.</p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">5. Cookies</h2>
              <p>We use essential cookies for theme preferences (light/dark mode) via `next-themes`. No tracking cookies are used in this prototype.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">6. Your Choices</h2>
              <p>You can "logout" to clear your simulated session data from `localStorage`. You can also manage `localStorage` and cookies directly through your browser settings.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">7. Changes to This Policy</h2>
              <p>We may update this Privacy Policy for the prototype. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">8. Contact Us</h2>
              <p>If you have any questions about this Privacy Policy for the CalcVerse prototype, please imagine contacting us at a hypothetical support email.</p>
            </section>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </>
  );
}
