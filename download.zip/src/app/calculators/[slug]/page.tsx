
"use client"; // This page now uses client-side hooks for auth

import { useEffect, useState } from 'react';
import { notFound, useRouter } from 'next/navigation';
import { Header } from '@/components/common/Header';
import { Footer } from '@/components/common/Footer';
import { getCalculatorBySlug, ALL_CALCULATORS } from '@/data/calculators';
import type { Calculator } from '@/types/calculators';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';
import { ChevronLeft, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { AuthPrompt } from '@/components/auth/AuthPrompt';

// Import actual calculator components here as they are created
import { StandardCalculator } from '@/components/calculators/StandardCalculator';
import { AgeCalculator } from '@/components/calculators/AgeCalculator';
import { DateDifferenceCalculator } from '@/components/calculators/DateDifferenceCalculator';
import { BMICalculator } from '@/components/calculators/BMICalculator';
import { EMICalculator } from '@/components/calculators/EMICalculator';
import { SIPCalculator } from '@/components/calculators/SIPCalculator';
import { GSTCalculator } from '@/components/calculators/GSTCalculator';
import { CurrencyConverter } from '@/components/calculators/CurrencyConverter';
import { ZakatCalculator } from '@/components/calculators/ZakatCalculator';
import { QurbaniCalculator } from '@/components/calculators/QurbaniCalculator';
import { MissedFastCalculator } from '@/components/calculators/MissedFastCalculator';
import { MurabahaProfitCalculator } from '@/components/calculators/MurabahaProfitCalculator';
import { CountdownTimer } from '@/components/calculators/CountdownTimer';

// Map slugs to components
const calculatorComponentMap: Record<string, React.ComponentType<any>> = {
  'standard-calculator': StandardCalculator,
  'age-calculator': AgeCalculator,
  'date-difference': DateDifferenceCalculator,
  'bmi-calculator': BMICalculator,
  'emi-calculator': EMICalculator,
  'sip-calculator': SIPCalculator,
  'gst-calculator': GSTCalculator,
  'currency-converter': CurrencyConverter,
  'zakat-calculator': ZakatCalculator,
  'qurbani-calculator': QurbaniCalculator,
  'missed-fast-calculator': MissedFastCalculator,
  'murabaha-profit-calculator': MurabahaProfitCalculator,
  'countdown-timer': CountdownTimer,
};

// export async function generateStaticParams() {
//   return ALL_CALCULATORS.map((calc) => ({
//     slug: calc.slug,
//   }));
// }
// Commenting out generateStaticParams as this page is now dynamic due to auth check

interface CalculatorPageProps {
  params: {
    slug: string;
  };
}

export default function CalculatorPage({ params }: CalculatorPageProps) {
  const { isAuthenticated, isLoading: isAuthLoading } = useAuth();
  const [calculator, setCalculator] = useState<Calculator | null | undefined>(undefined); // undefined for initial, null for not found
  const [authChecked, setAuthChecked] = useState(false);
  const router = useRouter(); // For potential redirects or re-checks

  useEffect(() => {
    const foundCalculator = getCalculatorBySlug(params.slug);
    if (!foundCalculator) {
      setCalculator(null); // Mark as not found
    } else {
      setCalculator(foundCalculator);
    }
  }, [params.slug]);
  
  // This effect waits for auth loading to finish before marking auth as checked
  useEffect(() => {
    if (!isAuthLoading) {
      setAuthChecked(true);
    }
  }, [isAuthLoading]);

  // Function to re-evaluate content after successful login/registration
  const handleAuthSuccess = () => {
    // This forces a re-render, and the useAuth hook will have updated isAuthenticated value
    // A more robust solution might involve a router.refresh() or a dedicated state update.
    setAuthChecked(false); // Reset to re-trigger auth check effect
    setTimeout(() => setAuthChecked(true), 0); // Re-enable after a tick
  };

  if (calculator === undefined || isAuthLoading) { // Loading state for calculator data or auth
    return (
      <>
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8 flex justify-center items-center">
          <Loader2 className="h-16 w-16 animate-spin text-primary" />
        </main>
        <Footer />
      </>
    );
  }

  if (calculator === null) {
    notFound(); // Trigger 404 if calculator data not found
  }
  
  // Ensure calculator is not null before proceeding
  if (!calculator) return null; // Should be caught by above notFound, but good for type safety

  const CalculatorComponent = calculatorComponentMap[calculator.slug] || (() => (
    <div className="text-center py-10">
      <p className="text-xl text-destructive">Calculator component not found.</p>
      <p className="text-muted-foreground">The component for '{calculator.name}' is not yet implemented.</p>
    </div>
  ));

  const renderContent = () => {
    if (!authChecked) { // If auth state hasn't been determined yet by the client
        return <div className="flex justify-center items-center min-h-[300px]"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>;
    }
    if (!isAuthenticated) {
      return <AuthPrompt calculatorName={calculator.name} onAuthSuccess={handleAuthSuccess} />;
    }
    return <CalculatorComponent />;
  };

  return (
    <>
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-6">
          <Button variant="outline" asChild>
            <Link href="/" className="text-primary hover:text-primary/80">
              <ChevronLeft className="mr-2 h-4 w-4" /> Back to Home
            </Link>
          </Button>
        </div>
        
        <Card className="w-full max-w-3xl mx-auto shadow-xl border-primary/10">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-2">
              <calculator.icon className="h-10 w-10 text-primary" aria-hidden="true" />
              <CardTitle className="font-headline text-3xl md:text-4xl font-bold text-primary">
                {calculator.name}
              </CardTitle>
            </div>
            {calculator.longDescription && (
              <CardDescription className="text-lg text-muted-foreground mt-2">
                {calculator.longDescription}
              </CardDescription>
            )}
          </CardHeader>
          <CardContent>
            {renderContent()}
          </CardContent>
        </Card>

        {isAuthenticated && calculator.features && calculator.features.length > 0 && (
          <section className="mt-12 max-w-3xl mx-auto">
            <h3 className="font-headline text-2xl font-semibold mb-4 text-foreground">Features</h3>
            <ul className="space-y-3">
              {calculator.features.map((feature, index) => (
                <li key={index} className="p-4 border rounded-lg bg-card shadow-sm">
                  <h4 className="font-medium text-lg text-primary">{feature.name}</h4>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </li>
              ))}
            </ul>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
