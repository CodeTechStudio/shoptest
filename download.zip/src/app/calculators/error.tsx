"use client"; 

import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { AlertTriangle } from "lucide-react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="text-center max-w-md p-8 bg-card rounded-lg shadow-xl">
        <AlertTriangle className="h-16 w-16 text-destructive mx-auto mb-6" />
        <h2 className="text-3xl font-bold text-destructive mb-4">Oops! Something went wrong.</h2>
        <p className="text-muted-foreground mb-6">
          We encountered an error trying to load this calculator. Please try again.
        </p>
        <p className="text-sm text-muted-foreground/70 mb-6">
          Error: {error.message}
        </p>
        <div className="space-x-4">
          <Button
            onClick={() => reset()}
            variant="destructive"
            size="lg"
          >
            Try again
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link href="/">Go to Homepage</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
