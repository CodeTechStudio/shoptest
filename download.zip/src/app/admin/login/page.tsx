
"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Atom, LogIn, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Keys for localStorage
const ADMIN_LOGGED_IN_KEY = 'calcverseAdminLoggedIn';
const ADMIN_USERNAME_KEY = 'calcverseAdminUsername';
const ADMIN_PASSWORD_KEY = 'calcverseAdminPassword'; // For mock password storage

// Default credentials if not found in localStorage
const DEFAULT_MOCK_ADMIN_USERNAME = "admin";
const DEFAULT_MOCK_ADMIN_PASSWORD = "password";

export default function AdminLoginPage() {
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    // If already logged in, redirect to dashboard
    if (localStorage.getItem(ADMIN_LOGGED_IN_KEY) === 'true') {
      router.replace('/admin/dashboard');
    }
  }, [router]);

  const handleLogin = () => {
    setIsLoading(true);

    // Get target credentials from localStorage or use defaults
    const targetUsername = localStorage.getItem(ADMIN_USERNAME_KEY) || DEFAULT_MOCK_ADMIN_USERNAME;
    const targetPassword = localStorage.getItem(ADMIN_PASSWORD_KEY) || DEFAULT_MOCK_ADMIN_PASSWORD;

    // Simulate API call
    setTimeout(() => {
      if (usernameInput === targetUsername && passwordInput === targetPassword) {
        localStorage.setItem(ADMIN_LOGGED_IN_KEY, 'true');
        // Ensure the username used for display in admin layout is also set/updated
        localStorage.setItem(ADMIN_USERNAME_KEY, usernameInput); 
        toast({ title: "Login Successful", description: "Redirecting to dashboard..." });
        router.push('/admin/dashboard');
      } else {
        toast({ title: "Login Failed", description: "Invalid username or password.", variant: "destructive" });
        setIsLoading(false);
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-muted/30 p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <Atom className="h-16 w-16 text-primary mx-auto mb-4" />
          <CardTitle className="text-3xl font-bold text-primary">CalcVerse Admin</CardTitle>
          <CardDescription>Please login to access the admin panel.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input 
              id="username" 
              placeholder={DEFAULT_MOCK_ADMIN_USERNAME}
              value={usernameInput} 
              onChange={(e) => setUsernameInput(e.target.value)} 
              disabled={isLoading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input 
              id="password" 
              type="password" 
              placeholder={DEFAULT_MOCK_ADMIN_PASSWORD} 
              value={passwordInput} 
              onChange={(e) => setPasswordInput(e.target.value)} 
              disabled={isLoading}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !isLoading) {
                  handleLogin();
                }
              }}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" onClick={handleLogin} disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <LogIn className="mr-2 h-4 w-4" />}
            Login
          </Button>
        </CardFooter>
      </Card>
      <p className="mt-4 text-xs text-muted-foreground">
        (Prototype: Default credentials are 'admin' / 'password' unless changed in settings)
      </p>
    </div>
  );
}
