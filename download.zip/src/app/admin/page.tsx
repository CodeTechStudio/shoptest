
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

export default function AdminRootPage() {
  const router = useRouter();

  useEffect(() => {
    // Ensure localStorage is accessed only on the client side
    if (typeof window !== 'undefined') {
      const isAdminLoggedIn = localStorage.getItem('calcverseAdminLoggedIn') === 'true';
      if (isAdminLoggedIn) {
        router.replace('/admin/dashboard');
      } else {
        router.replace('/admin/login');
      }
    }
  }, [router]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-muted/30">
      <Loader2 className="h-12 w-12 animate-spin text-primary" />
      <p className="ml-4 mt-4 text-lg text-muted-foreground">Loading Admin Area...</p>
    </div>
  );
}
