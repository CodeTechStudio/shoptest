
"use client";

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Settings,
  Users,
  FileText,
  LogOut,
  Menu,
  Atom,
  Palette,
  Newspaper,
  BarChart3
} from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useToast } from '@/hooks/use-toast';
import { useSiteSettings } from '@/hooks/use-site-settings';

const AdminSidebarNavItems = [
  { href: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/admin/settings', label: 'Site Settings', icon: Settings },
  { href: '/admin/users', label: 'User Management', icon: Users },
  { href: '/admin/content', label: 'Content Management', icon: Newspaper },
  // Add more admin links here
];

export default function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [isClient, setIsClient] = useState(false);
  const [adminUsername, setAdminUsername] = useState<string | null>(null);
  const { siteName } = useSiteSettings();

  useEffect(() => {
    setIsClient(true);
    const loggedIn = localStorage.getItem('calcverseAdminLoggedIn') === 'true';
    const username = localStorage.getItem('calcverseAdminUsername');
    if (!loggedIn) {
      router.replace('/admin/login');
    } else {
      setAdminUsername(username);
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('calcverseAdminLoggedIn');
    localStorage.removeItem('calcverseAdminUsername');
    toast({ title: "Logged Out", description: "You have been logged out of the admin panel." });
    router.push('/admin/login');
  };

  if (!isClient || !adminUsername) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-muted/30">
        <Atom className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-muted/30">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 flex-col border-r bg-background p-4 space-y-4">
        <div className="flex items-center space-x-2 mb-4">
          <Atom className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold text-primary">{siteName} Admin</span>
        </div>
        <nav className="flex-grow space-y-1">
          {AdminSidebarNavItems.map((item) => (
            <Button
              key={item.label}
              variant="ghost"
              className="w-full justify-start"
              asChild
            >
              <Link href={item.href}>
                <item.icon className="mr-2 h-4 w-4" />
                {item.label}
              </Link>
            </Button>
          ))}
        </nav>
        <div>
          <p className="text-sm text-muted-foreground mb-2">Logged in as: {adminUsername}</p>
          <Button variant="outline" className="w-full" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" /> Logout
          </Button>
        </div>
      </aside>

      {/* Mobile Sidebar & Main Content */}
      <div className="flex-1 flex flex-col">
        <header className="md:hidden sticky top-0 z-10 flex h-16 items-center justify-between border-b bg-background px-4">
          <div className="flex items-center space-x-2">
            <Atom className="h-7 w-7 text-primary" />
            <span className="text-lg font-bold text-primary">{siteName} Admin</span>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-4 flex flex-col">
              <div className="flex items-center space-x-2 mb-6">
                 <Atom className="h-8 w-8 text-primary" />
                 <span className="text-xl font-bold text-primary">{siteName} Admin</span>
              </div>
              <nav className="flex-grow space-y-1">
                {AdminSidebarNavItems.map((item) => (
                  <Button
                    key={item.label}
                    variant="ghost"
                    className="w-full justify-start"
                    asChild
                  >
                    <Link href={item.href}>
                      <item.icon className="mr-2 h-4 w-4" />
                      {item.label}
                    </Link>
                  </Button>
                ))}
              </nav>
               <div>
                <p className="text-sm text-muted-foreground mb-2">Logged in as: {adminUsername}</p>
                <Button variant="outline" className="w-full" onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" /> Logout
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </header>
        <main className="flex-1 p-6 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
