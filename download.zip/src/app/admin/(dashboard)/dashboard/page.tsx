
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3, FileText, Palette, Settings, Users, Briefcase, Link as LinkIcon } from 'lucide-react';
import Link from 'next/link';

const DashboardCard = ({ title, description, icon: Icon, href }: { title: string, description: string, icon: React.ElementType, href: string }) => (
  <Link href={href} className="block hover:shadow-lg transition-shadow rounded-lg">
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
        <Icon className="h-6 w-6 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  </Link>
);

export default function AdminDashboardPage() {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage your CalcVerse application.</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard 
          title="Site Settings" 
          description="Modify global site configurations like name, colors, and copyright." 
          icon={Settings}
          href="/admin/settings" 
        />
        <DashboardCard 
          title="User Management" 
          description="View and manage registered users (Placeholder)." 
          icon={Users}
          href="/admin/users" 
        />
         <DashboardCard 
          title="Content Management" 
          description="Manage calculator categories, legal pages, etc. (Placeholder)." 
          icon={Briefcase}
          href="/admin/content" 
        />
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center"><BarChart3 className="mr-2 h-5 w-5" /> Analytics Overview (Placeholder)</CardTitle>
            <CardDescription>Key metrics about your website's performance.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <p className="text-3xl font-bold">1,234</p>
                <p className="text-xs text-muted-foreground">Today's Visitors</p>
              </div>
              <div>
                <p className="text-3xl font-bold">56</p>
                <p className="text-xs text-muted-foreground">New Users (24h)</p>
              </div>
              <div>
                <p className="text-3xl font-bold">789</p>
                <p className="text-xs text-muted-foreground">Calculators Used (24h)</p>
              </div>
               <div>
                <p className="text-3xl font-bold">4.5/5</p>
                <p className="text-xs text-muted-foreground">Avg. Rating</p>
              </div>
            </div>
             <p className="text-center text-sm text-muted-foreground mt-6">Full analytics integration coming soon.</p>
          </CardContent>
        </Card>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-foreground mb-4">Quick Actions (Placeholders)</h2>
        <div className="space-y-3">
            <p className="text-sm text-muted-foreground">This section would contain links to frequently used admin tasks.</p>
            <ul className="list-disc list-inside text-primary space-y-1">
                <li>Create New Calculator Category</li>
                <li>Add New Calculator</li>
                <li>Update Privacy Policy</li>
                <li>Change Admin Password</li>
            </ul>
        </div>
      </section>
    </div>
  );
}
