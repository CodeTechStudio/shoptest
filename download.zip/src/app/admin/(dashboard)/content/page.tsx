
"use client";

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Edit, FileText, PlusCircle, Trash2 } from 'lucide-react';

// Mock Data
const mockCategories = [
  { id: 'cat_1', name: 'Basic Math', calculatorCount: 3 },
  { id: 'cat_2', name: 'Finance & Tax', calculatorCount: 4 },
  { id: 'cat_3', name: 'Health & Fitness', calculatorCount: 1 },
];

const mockLegalPages = [
  { id: 'legal_1', title: 'Privacy Policy', lastUpdated: '2024-07-01' },
  { id: 'legal_2', title: 'Terms of Service', lastUpdated: '2024-07-01' },
];

export default function AdminContentPage() {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-foreground">Content Management</h1>
        <p className="text-muted-foreground">Manage calculator categories and legal pages (Placeholders).</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Calculator Categories (Placeholder)</CardTitle>
          <CardDescription>View, add, or remove calculator categories.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockCategories.map(cat => (
              <div key={cat.id} className="flex items-center justify-between p-3 border rounded-md bg-card">
                <div>
                  <p className="font-medium">{cat.name}</p>
                  <p className="text-xs text-muted-foreground">{cat.calculatorCount} calculator(s)</p>
                </div>
                <div className="space-x-2">
                  <Button variant="ghost" size="icon" aria-label="Edit Category">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" aria-label="Delete Category" className="text-destructive hover:text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <Button variant="outline" className="mt-4">
            <PlusCircle className="mr-2 h-4 w-4" /> Add New Category
          </Button>
        </CardContent>
        <CardFooter>
           <p className="text-xs text-muted-foreground">Actual category management requires backend integration.</p>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Legal Pages (Placeholder)</CardTitle>
          <CardDescription>Edit content for Privacy Policy, Terms of Service, etc.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {mockLegalPages.map(page => (
            <div key={page.id} className="p-4 border rounded-md bg-card">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium">{page.title}</h3>
                <Button variant="outline" size="sm"><Edit className="mr-2 h-4 w-4" /> Edit Content</Button>
              </div>
              <p className="text-xs text-muted-foreground">Last Updated: {page.lastUpdated}</p>
              <div className="mt-2">
                <Label htmlFor={`content-${page.id}`} className="sr-only">Content for {page.title}</Label>
                <Textarea id={`content-${page.id}`} readOnly value={`This is placeholder content for the ${page.title}. Actual editing would involve a rich text editor or similar.`} rows={3} className="bg-muted/50"/>
              </div>
            </div>
          ))}
        </CardContent>
         <CardFooter>
           <p className="text-xs text-muted-foreground">Actual content editing requires backend integration.</p>
        </CardFooter>
      </Card>
    </div>
  );
}
