
"use client";

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useSiteSettings } from '@/hooks/use-site-settings';
import { Save, UploadCloud, Loader2, Palette, KeyRound, UserCog } from 'lucide-react';

const parseHslString = (hslString: string | undefined): [string, string, string] => {
    if (!hslString || typeof hslString !== 'string') return ['', '', ''];
    const parts = hslString.split(" ").map(val => val.replace('%',''));
    if (parts.length === 3) {
      return [parts[0], parts[1], parts[2]];
    }
    return ['', '', ''];
};

const DEFAULT_ADMIN_USERNAME_KEY = 'calcverseAdminUsername';
const DEFAULT_ADMIN_PASSWORD_KEY = 'calcverseAdminPassword'; 

export default function AdminSettingsPage() {
  const {
    siteName: globalSiteName, setSiteName: setGlobalSiteName,
    copyrightText: globalCopyrightText, setCopyrightText: setGlobalCopyrightText,
    primaryColor: globalPrimaryColor, setPrimaryColor: setGlobalPrimaryColor,
    backgroundColor: globalBackgroundColor, setBackgroundColor: setGlobalBackgroundColor,
    accentColor: globalAccentColor, setAccentColor: setGlobalAccentColor,
    isLoading: isSiteSettingsLoading
  } = useSiteSettings();

  const [localSiteName, setLocalSiteName] = useState("");
  const [localCopyrightText, setLocalCopyrightText] = useState("");

  const [primaryH, setPrimaryH] = useState('');
  const [primaryS, setPrimaryS] = useState('');
  const [primaryL, setPrimaryL] = useState('');

  const [backgroundH, setBackgroundH] = useState('');
  const [backgroundS, setBackgroundS] = useState('');
  const [backgroundL, setBackgroundL] = useState('');

  const [accentH, setAccentH] = useState('');
  const [accentS, setAccentS] = useState('');
  const [accentL, setAccentL] = useState('');

  const [newAdminUsername, setNewAdminUsername] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [confirmNewAdminPassword, setConfirmNewAdminPassword] = useState('');

  const [isSavingSiteInfo, setIsSavingSiteInfo] = useState(false);
  const [isSavingPrimaryColor, setIsSavingPrimaryColor] = useState(false);
  const [isSavingBackgroundColor, setIsSavingBackgroundColor] = useState(false);
  const [isSavingAccentColor, setIsSavingAccentColor] = useState(false);
  const [isSavingAdminCreds, setIsSavingAdminCreds] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    if (!isSiteSettingsLoading) {
      setLocalSiteName(globalSiteName);
      setLocalCopyrightText(globalCopyrightText);

      const [pH, pS, pL] = parseHslString(globalPrimaryColor);
      setPrimaryH(pH); setPrimaryS(pS); setPrimaryL(pL);

      const [bgH, bgS, bgL] = parseHslString(globalBackgroundColor);
      setBackgroundH(bgH); setBackgroundS(bgS); setBackgroundL(bgL);

      const [acH, acS, acL] = parseHslString(globalAccentColor);
      setAccentH(acH); setAccentS(acS); setAccentL(acL);
    }
    if (typeof window !== 'undefined') {
        const currentAdminUser = localStorage.getItem(DEFAULT_ADMIN_USERNAME_KEY);
        if (currentAdminUser) {
            setNewAdminUsername(currentAdminUser);
        } else {
            setNewAdminUsername("admin"); // Default if not set
        }
    }
  }, [globalSiteName, globalCopyrightText, globalPrimaryColor, globalBackgroundColor, globalAccentColor, isSiteSettingsLoading]);

  const handleSaveSiteInfo = useCallback(() => {
    setIsSavingSiteInfo(true);
    setGlobalSiteName(localSiteName);
    setGlobalCopyrightText(localCopyrightText);
    setTimeout(() => {
      setIsSavingSiteInfo(false);
      toast({ title: "Site Information Saved", description: "Website name and copyright updated." });
    }, 500);
  }, [localSiteName, localCopyrightText, setGlobalSiteName, setGlobalCopyrightText, toast]);

  const validateAndSaveColor = useCallback((
    hStr: string, sStr: string, lStr: string,
    setter: (hslString: string) => void,
    setIsLoadingState: (loading: boolean) => void,
    colorName: string
  ) => {
    setIsLoadingState(true);
    const h = parseInt(hStr, 10);
    const s = parseInt(sStr, 10);
    const l = parseInt(lStr, 10);

    if (isNaN(h) || h < 0 || h > 360 ||
        isNaN(s) || s < 0 || s > 100 ||
        isNaN(l) || l < 0 || l > 100) {
      toast({ title: `Invalid HSL values for ${colorName}`, description: "Hue: 0-360, Sat/Light: 0-100.", variant: "destructive" });
      setIsLoadingState(false);
      return;
    }

    const newHSL = `${h} ${s}% ${l}%`;
    setter(newHSL); 
    setTimeout(() => {
      setIsLoadingState(false);
      toast({ title: `${colorName} Updated`, description: `${colorName} has been changed.` });
    }, 500);
  }, [toast]);

  const handleSavePrimaryColor = useCallback(() => validateAndSaveColor(primaryH, primaryS, primaryL, setGlobalPrimaryColor, setIsSavingPrimaryColor, "Primary Color"), [primaryH, primaryS, primaryL, setGlobalPrimaryColor, validateAndSaveColor]);
  const handleSaveBackgroundColor = useCallback(() => validateAndSaveColor(backgroundH, backgroundS, backgroundL, setGlobalBackgroundColor, setIsSavingBackgroundColor, "Background Color"), [backgroundH, backgroundS, backgroundL, setGlobalBackgroundColor, validateAndSaveColor]);
  const handleSaveAccentColor = useCallback(() => validateAndSaveColor(accentH, accentS, accentL, setGlobalAccentColor, setIsSavingAccentColor, "Accent Color"), [accentH, accentS, accentL, setGlobalAccentColor, validateAndSaveColor]);

  const handleAdminAccountReset = () => {
    if (!newAdminUsername.trim()) {
        toast({ title: "Error", description: "New admin username cannot be empty.", variant: "destructive" });
        return;
    }
    if (newAdminPassword.length < 6) {
        toast({ title: "Error", description: "New password must be at least 6 characters long.", variant: "destructive" });
        return;
    }
    if (newAdminPassword !== confirmNewAdminPassword) {
        toast({ title: "Error", description: "New passwords do not match.", variant: "destructive" });
        return;
    }
    setIsSavingAdminCreds(true);
    if (typeof window !== 'undefined') {
        localStorage.setItem(DEFAULT_ADMIN_USERNAME_KEY, newAdminUsername.trim());
        localStorage.setItem(DEFAULT_ADMIN_PASSWORD_KEY, newAdminPassword);
    }

    setTimeout(() => {
        setIsSavingAdminCreds(false);
        toast({ title: "Admin Credentials Updated (Mock)", description: "Username and password have been 'reset'. You may need to log out and log back in with the new credentials.", variant: "default" });
        setNewAdminPassword('');
        setConfirmNewAdminPassword('');
    }, 1000);
  };

  if (isSiteSettingsLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="mt-4 text-lg text-muted-foreground">Loading settings...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-foreground">Site Settings</h1>
        <p className="text-muted-foreground">Customize your application's appearance and information.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>General Information</CardTitle>
          <CardDescription>Update basic site details.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1">
            <Label htmlFor="siteName">Website Name</Label>
            <Input id="siteName" value={localSiteName} onChange={(e) => setLocalSiteName(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="copyrightText">Copyright Text</Label>
            <Input id="copyrightText" value={localCopyrightText} onChange={(e) => setLocalCopyrightText(e.target.value)} />
            <p className="text-xs text-muted-foreground">Use {'{{year}}'} for the current year.</p>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSaveSiteInfo} disabled={isSavingSiteInfo}>
            {isSavingSiteInfo ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save Site Info
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Palette className="mr-2 h-5 w-5 text-primary" /> Theme Colors</CardTitle>
          <CardDescription>Modify the core colors of your website using HSL values. Changes apply live when saved.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {/* Primary Color */}
          <section className="p-4 border rounded-md bg-card shadow-sm">
            <h3 className="text-lg font-medium text-primary mb-3">Primary Color</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label htmlFor="primaryH">Hue (0-360)</Label>
                <Input id="primaryH" type="number" min="0" max="360" value={primaryH} onChange={(e) => setPrimaryH(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="primaryS">Saturation (0-100%)</Label>
                <Input id="primaryS" type="number" min="0" max="100" value={primaryS} onChange={(e) => setPrimaryS(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="primaryL">Lightness (0-100%)</Label>
                <Input id="primaryL" type="number" min="0" max="100" value={primaryL} onChange={(e) => setPrimaryL(e.target.value)} />
              </div>
            </div>
            <div className="flex items-center space-x-2 mt-3">
              <span className="text-sm text-muted-foreground">Preview:</span>
              <div className="h-8 w-16 rounded border" style={{ backgroundColor: `hsl(${primaryH || 0} ${primaryS || 0}% ${primaryL || 0}%)`}} />
            </div>
            <Button onClick={handleSavePrimaryColor} disabled={isSavingPrimaryColor} className="mt-4">
              {isSavingPrimaryColor ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Save Primary Color
            </Button>
          </section>

          {/* Background Color */}
          <section className="p-4 border rounded-md bg-card shadow-sm">
            <h3 className="text-lg font-medium text-primary mb-3">Background Color</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label htmlFor="backgroundH">Hue (0-360)</Label>
                <Input id="backgroundH" type="number" min="0" max="360" value={backgroundH} onChange={(e) => setBackgroundH(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="backgroundS">Saturation (0-100%)</Label>
                <Input id="backgroundS" type="number" min="0" max="100" value={backgroundS} onChange={(e) => setBackgroundS(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="backgroundL">Lightness (0-100%)</Label>
                <Input id="backgroundL" type="number" min="0" max="100" value={backgroundL} onChange={(e) => setBackgroundL(e.target.value)} />
              </div>
            </div>
            <div className="flex items-center space-x-2 mt-3">
              <span className="text-sm text-muted-foreground">Preview:</span>
              <div className="h-8 w-16 rounded border" style={{ backgroundColor: `hsl(${backgroundH || 0} ${backgroundS || 0}% ${backgroundL || 0}%)`}} />
            </div>
            <Button onClick={handleSaveBackgroundColor} disabled={isSavingBackgroundColor} className="mt-4">
              {isSavingBackgroundColor ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Save Background Color
            </Button>
          </section>

          {/* Accent Color */}
          <section className="p-4 border rounded-md bg-card shadow-sm">
            <h3 className="text-lg font-medium text-primary mb-3">Accent Color</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label htmlFor="accentH">Hue (0-360)</Label>
                <Input id="accentH" type="number" min="0" max="360" value={accentH} onChange={(e) => setAccentH(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="accentS">Saturation (0-100%)</Label>
                <Input id="accentS" type="number" min="0" max="100" value={accentS} onChange={(e) => setAccentS(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="accentL">Lightness (0-100%)</Label>
                <Input id="accentL" type="number" min="0" max="100" value={accentL} onChange={(e) => setAccentL(e.target.value)} />
              </div>
            </div>
            <div className="flex items-center space-x-2 mt-3">
              <span className="text-sm text-muted-foreground">Preview:</span>
              <div className="h-8 w-16 rounded border" style={{ backgroundColor: `hsl(${accentH || 0} ${accentS || 0}% ${accentL || 0}%)`}} />
            </div>
            <Button onClick={handleSaveAccentColor} disabled={isSavingAccentColor} className="mt-4">
              {isSavingAccentColor ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Save Accent Color
            </Button>
          </section>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Logo Management (Placeholder)</CardTitle>
          <CardDescription>Update your website's logo. This is a UI placeholder.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="flex items-center space-x-4">
                <div className="w-20 h-20 bg-muted rounded flex items-center justify-center text-muted-foreground">
                    Current Logo
                </div>
                <Button variant="outline">
                    <UploadCloud className="mr-2 h-4 w-4" /> Upload New Logo
                </Button>
            </div>
            <p className="text-xs text-muted-foreground">Actual file upload functionality requires backend integration.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><UserCog className="mr-2 h-5 w-5 text-primary" /> Admin Account (Mock)</CardTitle>
          <CardDescription>Update your admin username and password (simulation only).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 p-4 border rounded-md bg-card">
            <div className="space-y-1">
                <Label htmlFor="newAdminUsername">New Admin Username</Label>
                <Input id="newAdminUsername" value={newAdminUsername} onChange={(e) => setNewAdminUsername(e.target.value)} placeholder="Enter new admin username" disabled={isSavingAdminCreds}/>
            </div>
            <div className="space-y-1">
                <Label htmlFor="newAdminPassword">New Password (min. 6 chars)</Label>
                <Input id="newAdminPassword" type="password" value={newAdminPassword} onChange={(e) => setNewAdminPassword(e.target.value)} placeholder="Enter new password" disabled={isSavingAdminCreds}/>
            </div>
            <div className="space-y-1">
                <Label htmlFor="confirmNewAdminPassword">Confirm New Password</Label>
                <Input id="confirmNewAdminPassword" type="password" value={confirmNewAdminPassword} onChange={(e) => setConfirmNewAdminPassword(e.target.value)} placeholder="Confirm new password" disabled={isSavingAdminCreds}/>
            </div>
            <Button onClick={handleAdminAccountReset} disabled={isSavingAdminCreds}>
                {isSavingAdminCreds ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
                Reset Admin Credentials
            </Button>
            <p className="text-xs text-muted-foreground pt-2">
                Important: This is a simulation. Credentials are 'saved' to browser storage and are not secure for production use.
            </p>
        </CardContent>
      </Card>
    </div>
  );
}

    