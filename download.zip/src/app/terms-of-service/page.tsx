
import { Header } from "@/components/common/Header";
import { Footer } from "@/components/common/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function TermsOfServicePage() {
  return (
    <>
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto shadow-lg">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-primary">Terms of Service</CardTitle>
            <CardDescription>Last updated: {new Date().toLocaleDateString()}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 text-muted-foreground">
            <p>Welcome to CalcVerse! These Terms of Service ("Terms") govern your use of the CalcVerse website and its calculator tools (the "Service"). Please read these Terms carefully. As this is a prototype application, these terms are simplified.</p>
            
            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">1. Acceptance of Terms</h2>
              <p>By accessing or using the Service, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access the Service.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">2. Use of the Service</h2>
              <p>CalcVerse provides a collection of calculator tools for various purposes. The Service is provided for informational and personal use only.</p>
              <ul className="list-disc list-inside ml-4 space-y-1 mt-2">
                <li>You may be required to "register" a mock account to use certain calculators. This registration is for simulation purposes within this prototype.</li>
                <li>You are responsible for any activity that occurs under your simulated account.</li>
                <li>You agree not to use the Service for any illegal or unauthorized purpose.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">3. Accuracy of Information</h2>
              <p>While we strive to ensure the accuracy of the calculations provided, CalcVerse is a prototype and should not be relied upon for critical financial, medical, or legal decisions. Calculations are for estimation and informational purposes only. Always verify critical calculations with a qualified professional or official sources.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">4. Intellectual Property</h2>
              <p>The Service and its original content (excluding user-provided data for calculations), features, and functionality are and will remain the exclusive property of CalcVerse and its licensors (in a real-world scenario).</p>
            </section>
            
            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">5. Disclaimer of Warranties</h2>
              <p>The Service is provided on an "AS IS" and "AS AVAILABLE" basis. CalcVerse makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">6. Limitation of Liability</h2>
              <p>In no event shall CalcVerse or its developers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on CalcVerse's website, even if CalcVerse or a CalcVerse authorized representative has been notified orally or in writing of the possibility of such damage.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">7. Changes to Terms</h2>
              <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will try to provide at least some notice prior to any new terms taking effect if this were a production application.</p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-foreground mb-2">8. Contact Us</h2>
              <p>If you have any questions about these Terms for the CalcVerse prototype, please imagine contacting us.</p>
            </section>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </>
  );
}
