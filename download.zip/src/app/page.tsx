import { Header } from "@/components/common/Header";
import { Footer } from "@/components/common/Footer";
import { HeroSection } from "@/components/homepage/HeroSection";
import { CategoryGrid } from "@/components/homepage/CategoryGrid";
import { FeaturedCalculators } from "@/components/homepage/FeaturedCalculators";

export default function HomePage() {
  return (
    <>
      <Header />
      <main className="flex-grow">
        <HeroSection />
        <CategoryGrid />
        <FeaturedCalculators />
      </main>
      <Footer />
    </>
  );
}
