
import { Header } from "@/components/common/Header";
import { Footer } from "@/components/common/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ALL_CALCULATORS, CATEGORIES } from "@/data/calculators";
import Link from "next/link";
import { Separator } from "@/components/ui/separator";

export default function SitemapPage() {
  return (
    <>
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <Card className="max-w-4xl mx-auto shadow-lg">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-primary">Sitemap</CardTitle>
            <CardDescription>Navigate through CalcVerse easily.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Main Pages</h2>
              <ul className="list-disc list-inside ml-4 space-y-2">
                <li><Link href="/" className="text-primary hover:underline">Homepage</Link></li>
                <li><Link href="/#categories" className="text-primary hover:underline">All Categories (on Homepage)</Link></li>
              </ul>
            </section>

            <Separator />

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Calculator Categories</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                {CATEGORIES.map(category => (
                  <div key={category.id}>
                    <Link href={`/categories/${category.slug}`} className="text-primary hover:underline font-medium text-lg">
                      {category.name}
                    </Link>
                  </div>
                ))}
              </div>
            </section>
            
            <Separator />

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-4">All Calculators</h2>
              {CATEGORIES.map(category => (
                <div key={`cat-list-${category.id}`} className="mb-6">
                  <h3 className="text-xl font-semibold text-primary/80 mb-2">{category.name}</h3>
                  <ul className="list-disc list-inside ml-4 space-y-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-4">
                    {ALL_CALCULATORS.filter(calc => calc.category === category.id).map(calculator => (
                      <li key={calculator.id}>
                        <Link href={`/calculators/${calculator.slug}`} className="text-muted-foreground hover:text-primary hover:underline">
                          {calculator.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </section>

            <Separator />

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Legal</h2>
              <ul className="list-disc list-inside ml-4 space-y-2">
                <li><Link href="/privacy-policy" className="text-primary hover:underline">Privacy Policy</Link></li>
                <li><Link href="/terms-of-service" className="text-primary hover:underline">Terms of Service</Link></li>
              </ul>
            </section>

          </CardContent>
        </Card>
      </main>
      <Footer />
    </>
  );
}
