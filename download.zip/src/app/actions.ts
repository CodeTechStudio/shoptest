"use server";

import { calculatorSuggestion, type CalculatorSuggestionInput, type CalculatorSuggestionOutput } from "@/ai/flows/calculator-suggestion";
import { getCalculatorByAiName } from "@/data/calculators";

export interface AISuggestionResult {
  calculatorName: string;
  reason: string;
  slug?: string; // Slug of the suggested calculator if found
}

export async function getAISuggestion(query: string): Promise<AISuggestionResult | { error: string }> {
  if (!query.trim()) {
    return { error: "Query cannot be empty." };
  }

  try {
    const input: CalculatorSuggestionInput = { query };
    const suggestion: CalculatorSuggestionOutput = await calculatorSuggestion(input);
    
    const suggestedCalculator = getCalculatorByAiName(suggestion.calculatorName);

    return {
      calculatorName: suggestion.calculatorName,
      reason: suggestion.reason,
      slug: suggestedCalculator?.slug,
    };
  } catch (error) {
    console.error("Error getting AI suggestion:", error);
    return { error: "Failed to get AI suggestion. Please try again." };
  }
}
