
export interface User {
  id: string;
  username: string;
  // Add other user properties here if needed in the future, e.g., email, avatarUrl
}
