import type { LucideIcon } from "lucide-react";

export interface CalculatorFeature {
  name: string;
  description: string;
}

export interface Calculator {
  id: string;
  slug: string;
  name: string;
  description: string;
  longDescription?: string;
  icon: LucideIcon;
  category: string; // Category ID/slug
  keywords?: string[];
  features?: CalculatorFeature[];
  isFeatured?: boolean;
  component: React.ComponentType<any>; // React component for the calculator
  aiPromptName?: string; // Name used in AI prompt
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  icon: LucideIcon;
  description?: string;
  calculatorCount?: number; // To be populated dynamically or statically
}
