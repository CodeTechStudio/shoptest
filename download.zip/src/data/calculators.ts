
import type { Calculator, Category } from '@/types/calculators';
import { 
    Calculator as CalculatorIcon, Ruler, CalendarDays, Coins, Scale, 
    HeartPulse, Brain, Settings, Sparkles, Milestone, Percent, LineChart,
    Users, CalendarX, ShieldCheck, Receipt, HandCoins, Banknote, Building, Equal, CheckSquare,
    Timer, MoonStar, LayoutGrid, Repeat 
} from 'lucide-react';

// Import actual components
import { StandardCalculator } from '@/components/calculators/StandardCalculator';
import { AgeCalculator } from '@/components/calculators/AgeCalculator';
import { DateDifferenceCalculator } from '@/components/calculators/DateDifferenceCalculator';
import { BMICalculator } from '@/components/calculators/BMICalculator';
import { EMICalculator } from '@/components/calculators/EMICalculator';
import { SIPCalculator } from '@/components/calculators/SIPCalculator';
import { GSTCalculator } from '@/components/calculators/GSTCalculator';
import { CurrencyConverter } from '@/components/calculators/CurrencyConverter';
import { ZakatCalculator } from '@/components/calculators/ZakatCalculator';
import { QurbaniCalculator } from '@/components/calculators/QurbaniCalculator';
import { MissedFastCalculator } from '@/components/calculators/MissedFastCalculator';
import { MurabahaProfitCalculator } from '@/components/calculators/MurabahaProfitCalculator';
import { CountdownTimer } from '@/components/calculators/CountdownTimer';


export const ALL_CALCULATORS: Calculator[] = [
  {
    id: 'standard-calculator',
    slug: 'standard-calculator',
    name: 'Standard Calculator',
    description: 'Basic arithmetic operations for everyday calculations.',
    longDescription: 'Perform addition, subtraction, multiplication, division, and percentage calculations with ease. Includes memory functions for more complex tasks.',
    icon: CalculatorIcon,
    category: 'basic-math',
    keywords: ['math', 'addition', 'subtraction', 'multiplication', 'division', 'basic'],
    isFeatured: true,
    component: StandardCalculator, 
    aiPromptName: 'Standard Calculator',
    features: [
        { name: 'Basic Operations', description: '+, -, ×, ÷' },
        { name: 'Percentage', description: 'Calculate percentages easily.' },
        { name: 'Memory Functions', description: 'MC, MR, M+, M- for storing and recalling numbers.' },
        { name: 'Keyboard Support', description: 'Use your keyboard for faster input.'}
    ]
  },
  {
    id: 'age-calculator',
    slug: 'age-calculator',
    name: 'Age Calculator',
    description: 'Calculate age from birthdate and to a target date.',
    longDescription: 'Find out your exact age in years, months, and days as of a specific target date (defaults to today). Also, discover when your next birthday will be (from today).',
    icon: CalendarDays,
    category: 'date-time',
    keywords: ['birthday', 'years', 'months', 'days', 'dob', 'next birthday', 'target date age'],
    isFeatured: true,
    component: AgeCalculator,
    aiPromptName: 'Age Calculator',
    features: [
        { name: 'Precise Age', description: 'Calculates age in years, months, and days.' },
        { name: 'Target Date Calculation', description: 'Calculate age as of any specific date.'},
        { name: 'Next Birthday', description: 'Shows the date of your next birthday and days remaining from today.' },
        { name: 'Easy Date Picker', description: 'User-friendly calendar to select birth date and target date.'}
    ]
  },
  {
    id: 'date-difference',
    slug: 'date-difference',
    name: 'Date Difference',
    description: 'Calculate the duration between two dates.',
    longDescription: 'Determine the exact number of years, months, and days, as well as the total number of days, between any two given dates.',
    icon: Milestone,
    category: 'date-time',
    keywords: ['duration', 'time span', 'interval', 'days between dates'],
    component: DateDifferenceCalculator, 
    aiPromptName: 'Date Difference',
    features: [
        { name: 'Flexible Date Input', description: 'Select any start and end date.' },
        { name: 'Detailed Breakdown', description: 'Shows difference in years, months, days.' },
        { name: 'Total Days', description: 'Calculates the total number of days between dates.'}
    ]
  },
  {
    id: 'countdown-timer',
    slug: 'countdown-timer',
    name: 'Countdown Timer',
    description: 'Set a future date and time to see a live countdown.',
    longDescription: 'Enter a specific future date and time, and the calculator will display a live countdown showing the remaining days, hours, minutes, and seconds until that moment.',
    icon: Timer,
    category: 'date-time',
    keywords: ['timer', 'event countdown', 'deadline', 'remaining time', 'future date'],
    isFeatured: true,
    component: CountdownTimer,
    aiPromptName: 'Countdown Timer',
    features: [
        { name: 'Date & Time Input', description: 'Select a future date and specify the exact time.' },
        { name: 'Live Countdown', description: 'Displays remaining days, hours, minutes, and seconds, updating every second.' },
        { name: 'Start/Pause Control', description: 'Ability to start and pause the countdown.' },
        { name: 'Clear Display', description: 'Shows a "Countdown Finished!" message upon completion.'}
    ]
  },
  {
    id: 'emi-calculator',
    slug: 'emi-calculator',
    name: 'EMI Calculator',
    description: 'Calculate loan equated monthly installments.',
    icon: Receipt, 
    category: 'finance-tax',
    keywords: ['loan', 'mortgage', 'interest', 'payment', 'installment', 'home', 'car'],
    isFeatured: true,
    component: EMICalculator,
    aiPromptName: 'EMI Calculator',
    longDescription: "Estimate your Equated Monthly Installment (EMI) for loans. Enter loan amount, interest rate, and tenure to see your monthly payment, total interest, and total principal plus interest.",
    features: [
        { name: "EMI Calculation", description: "Accurately calculates your monthly loan payment." },
        { name: "Total Interest & Payment", description: "Shows total interest paid and total amount over loan tenure." },
        { name: "Flexible Tenure Input", description: "Enter loan tenure in years or months." },
        { name: "Visual Breakdown", description: "Pie chart showing principal vs. interest components." }
    ]
  },
  {
    id: 'sip-calculator',
    slug: 'sip-calculator',
    name: 'SIP Calculator',
    description: 'Estimate returns on SIP investments.',
    icon: LineChart, 
    category: 'finance-tax',
    keywords: ['investment', 'mutual fund', 'savings', 'return', 'systematic investment plan'],
    isFeatured: true,
    component: SIPCalculator, 
    aiPromptName: 'SIP Calculator',
    longDescription: "Project the future value of your Systematic Investment Plan (SIP). Input your monthly investment, expected return rate, and investment period to see your estimated returns and total corpus.",
    features: [
        { name: "Future Value Projection", description: "Estimates total value of your SIP investments." },
        { name: "Return Estimation", description: "Calculates potential wealth gain." },
        { name: "Growth Visualization", description: "Bar chart showing investment growth over time." }
    ]
  },
  {
    id: 'gst-calculator',
    slug: 'gst-calculator',
    name: 'GST Calculator',
    description: 'Calculate Goods and Services Tax amounts.',
    icon: Percent, 
    category: 'finance-tax',
    keywords: ['tax', 'vat', 'sales tax', 'invoice', 'goods and services tax'],
    isFeatured: true,
    component: GSTCalculator,
    aiPromptName: 'GST Calculator',
    longDescription: "Easily calculate Goods and Services Tax (GST). Add GST to a base price or extract GST from an inclusive price. Supports common GST rates and custom inputs.",
    features: [
        { name: "Add/Remove GST", description: "Calculate GST for inclusive or exclusive amounts." },
        { name: "Common GST Slabs", description: "Quick selection for standard GST rates (5%, 12%, 18%, 28%)." },
        { name: "Custom Rate Input", description: "Allows for specific or non-standard GST percentages." },
        { name: "Clear Breakdown", description: "Shows base amount, GST amount, and total amount." }
    ]
  },
  {
    id: 'currency-converter',
    slug: 'currency-converter',
    name: 'Currency Converter',
    description: 'Convert between different world currencies (mock).',
    icon: HandCoins,
    category: 'converters',
    keywords: ['exchange rate', 'money', 'forex', 'travel money', 'usd', 'eur', 'gbp', 'inr', 'jpy'],
    component: CurrencyConverter, 
    aiPromptName: 'Currency Converter',
    longDescription: "Convert amounts between different currencies. This version uses mock exchange rates for demonstration purposes. In a full application, this would connect to a live exchange rate API.",
    features: [
        { name: "Currency Selection", description: "Choose from a list of common currencies." },
        { name: "Amount Input", description: "Enter the amount to convert." },
        { name: "Swap Currencies", description: "Easily swap 'from' and 'to' currencies." },
        { name: "Mock Conversion", description: "Shows converted amount based on pre-defined rates (for demo)." }
    ]
  },
  {
    id: 'bmi-calculator',
    slug: 'bmi-calculator',
    name: 'BMI Calculator',
    description: 'Calculate Body Mass Index for health assessment.',
    longDescription: 'Determine your Body Mass Index (BMI) using your height and weight. Understand your weight category (underweight, normal, overweight, or obese).',
    icon: Scale,
    category: 'health-fitness',
    keywords: ['health', 'weight', 'fitness', 'obesity', 'body mass index'],
    isFeatured: true,
    component: BMICalculator,
    aiPromptName: 'BMI Calculator',
    features: [
        { name: 'Multiple Units', description: 'Enter height in cm or ft/in, weight in kg or lbs.' },
        { name: 'Clear Results', description: 'Displays BMI value and weight category.' },
        { name: 'BMI Categories Chart', description: 'Shows standard BMI categories for reference.'}
    ]
  },
  {
    id: 'zakat-calculator',
    slug: 'zakat-calculator',
    name: 'Zakat Calculator',
    description: 'Calculate your Islamic charity obligation (Zakat).',
    icon: Coins,
    category: 'islamic-tools',
    keywords: ['islam', 'charity', 'nisab', 'wealth', 'muslim', 'zakah', 'obligation', 'assets'],
    isFeatured: true,
    component: ZakatCalculator, 
    aiPromptName: 'Zakat Calculator',
    longDescription: "Calculate your annual Zakat obligation. Input your various assets (cash, gold, silver, investments, business goods) and deductible liabilities along with the current Nisab threshold to determine the Zakat payable.",
    features: [
        { name: "Comprehensive Asset Input", description: "Fields for cash, gold value, silver value, business assets, and shares/investments." },
        { name: "Liability Deduction", description: "Allows deduction of short-term liabilities." },
        { name: "Nisab Threshold Input", description: "User provides the current Nisab value for accuracy." },
        { name: "Clear Zakat Due", description: "Displays total Zakatable assets and the precise Zakat amount if Nisab is met." }
    ]
  },
  {
    id: 'qurbani-calculator',
    slug: 'qurbani-calculator',
    name: 'Qurbani Share Calculator',
    description: 'Calculate the cost per share for Qurbani/Udhiyah.',
    icon: Users,
    category: 'islamic-tools',
    keywords: ['islam', 'eid', 'udhiyah', 'sacrifice', 'animal share', 'cost division'],
    component: QurbaniCalculator,
    aiPromptName: 'Qurbani Calculator',
    longDescription: "Easily determine the cost per share for a sacrificial animal (Qurbani/Udhiyah). Enter the total cost of the animal and the number of shares to find out the contribution needed per share.",
    features: [
        { name: "Total Cost Input", description: "Enter the full price of the sacrificial animal." },
        { name: "Number of Shares", description: "Specify how many shares the animal is divided into (e.g., 1 or 7)." },
        { name: "Cost Per Share", description: "Clearly displays the calculated cost for each share." }
    ]
  },
  {
    id: 'missed-fast-calculator',
    slug: 'missed-fast-calculator',
    name: 'Missed Fast (Roza) Fidya Calculator',
    description: 'Calculate the Fidya payable for missed Ramadan fasts.',
    icon: CalendarX,
    category: 'islamic-tools',
    keywords: ['islam', 'ramadan', 'fasting', 'roza', 'fidya', 'kaffara', 'compensation'],
    component: MissedFastCalculator,
    aiPromptName: 'Missed Fast Calculator',
    longDescription: "Calculate the total Fidya (compensation) due for fasts missed during Ramadan for valid reasons, when they cannot be made up later. Enter the number of missed fasts and the Fidya amount per fast.",
    features: [
        { name: "Number of Missed Fasts", description: "Input the count of fasts that require Fidya." },
        { name: "Fidya Amount Per Fast", description: "Enter the monetary value of Fidya for one fast (consult local scholars)." },
        { name: "Total Fidya Payable", description: "Calculates the total amount to be paid as Fidya." }
    ]
  },
   {
    id: 'murabaha-profit-calculator',
    slug: 'murabaha-profit-calculator',
    name: 'Murabaha Profit Calculator',
    description: 'Calculate profit and installments for a Murabaha (cost-plus profit) transaction.',
    icon: ShieldCheck,
    category: 'islamic-tools',
    keywords: ['islamic finance', 'halal loan', 'murabaha', 'cost-plus profit', 'installments', 'islamic banking'],
    component: MurabahaProfitCalculator,
    aiPromptName: 'Islamic Loan Profit Calculator', // Kept existing AI name based on previous context
    longDescription: "Calculate the selling price, total profit, and monthly installments for an Islamic financing transaction based on the Murabaha (cost-plus profit) model. This is not an interest-based loan.",
    features: [
        { name: "Asset Cost Input", description: "Enter the original cost of the asset to be financed." },
        { name: "Profit Margin Input", description: "Specify the agreed profit margin as a percentage." },
        { name: "Tenure Input", description: "Enter the financing period in years or months." },
        { name: "Calculated Results", description: "Shows total profit, final selling price, and monthly installment amount." }
    ]
  },
];

export const CATEGORIES: Category[] = [
  {
    id: 'basic-math', 
    slug: 'basic-math',
    name: 'Basic Math',
    icon: CalculatorIcon, 
    description: 'Fundamental mathematical tools for everyday use.',
  },
  {
    id: 'date-time',
    slug: 'date-time',
    name: 'Date & Time',
    icon: CalendarDays,
    description: 'Calculators for managing dates, times, and durations.',
  },
  {
    id: 'finance-tax',
    slug: 'finance-tax',
    name: 'Finance & Tax',
    icon: Banknote, 
    description: 'Tools for financial planning, loans, investments, and tax calculations.',
  },
  {
    id: 'health-fitness',
    slug: 'health-fitness',
    name: 'Health & Fitness',
    icon: HeartPulse,
    description: 'Calculators for monitoring health metrics and fitness goals.',
  },
  {
    id: 'islamic-tools', 
    slug: 'islamic-tools',
    name: 'Islamic Tools',
    icon: MoonStar, 
    description: 'Calculators related to Islamic practices, finance, and obligations.',
  },
  {
    id: 'converters', 
    slug: 'converters',
    name: 'Converters',
    icon: Repeat, 
    description: 'Tools for converting between different units and currencies.',
  },
  {
    id: 'miscellaneous',
    slug: 'miscellaneous',
    name: 'Miscellaneous Tools',
    icon: Sparkles, 
    description: 'A variety of other useful calculators.',
  },
].map(category => ({
  ...category,
  calculatorCount: ALL_CALCULATORS.filter(calc => calc.category === category.id).length,
})).filter(category => category.calculatorCount > 0 || ['basic-math', 'miscellaneous', 'converters', 'date-time', 'finance-tax', 'health-fitness', 'islamic-tools'].includes(category.id) ); // Ensure all primary categories are shown

export const getCalculatorBySlug = (slug: string): Calculator | undefined => {
  return ALL_CALCULATORS.find(calc => calc.slug === slug);
};

export const getCalculatorsByCategory = (categorySlug: string): Calculator[] => {
  return ALL_CALCULATORS.filter(calc => calc.category === categorySlug);
};

export const getFeaturedCalculators = (): Calculator[] => {
  return ALL_CALCULATORS.filter(calc => calc.isFeatured).slice(0, 6);
};

export const AI_CALCULATOR_NAMES = ALL_CALCULATORS.map(calc => calc.aiPromptName || calc.name);

export const getCalculatorByAiName = (aiName: string): Calculator | undefined => {
  return ALL_CALCULATORS.find(calc => calc.aiPromptName === aiName || calc.name === aiName);
};

