
"use client"; // Make it a client component to use the hook

import Link from "next/link";
import { useSiteSettings } from "@/hooks/use-site-settings"; // Import useSiteSettings
import { useEffect, useState } from "react";

export function Footer() {
  const { siteName, copyrightText: rawCopyrightText, isLoading: isSiteSettingsLoading } = useSiteSettings();
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  
  useEffect(() => {
    setCurrentYear(new Date().getFullYear());
  }, []);

  const processedCopyrightText = isSiteSettingsLoading 
    ? `© ${currentYear} CalcVerse. All rights reserved.` 
    : rawCopyrightText.replace("{{year}}", currentYear.toString());

  const currentSiteName = isSiteSettingsLoading ? "CalcVerse" : siteName;

  return (
    <footer className="mt-auto border-t border-border/40 py-8 bg-muted/30 dark:bg-muted/10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left mb-8">
          <div>
            <h3 className="font-semibold text-foreground mb-2">{currentSiteName}</h3>
            <p className="text-sm text-muted-foreground">
              Calculate Anything. Instantly. Smartly.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">Quick Links</h3>
            <ul className="space-y-1 text-sm">
              <li><Link href="/" className="text-muted-foreground hover:text-primary">Home</Link></li>
              <li><Link href="/#categories" className="text-muted-foreground hover:text-primary">Categories</Link></li>
              <li><Link href="/sitemap" className="text-muted-foreground hover:text-primary">Sitemap</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">Legal</h3>
            <ul className="space-y-1 text-sm">
              <li><Link href="/privacy-policy" className="text-muted-foreground hover:text-primary">Privacy Policy</Link></li>
              <li><Link href="/terms-of-service" className="text-muted-foreground hover:text-primary">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border/40 pt-8 text-center text-sm text-muted-foreground">
          <p>{processedCopyrightText}</p>
        </div>
      </div>
    </footer>
  );
}
