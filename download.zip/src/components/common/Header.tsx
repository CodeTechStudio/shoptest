
"use client";

import Link from "next/link";
import { Atom, LogIn, UserPlus, ChevronDown, UserCircle, LogOut, LayoutGrid } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/use-auth";
import { LoginModal } from "@/components/auth/LoginModal";
import { RegisterModal } from "@/components/auth/RegisterModal";
import { CATEGORIES } from "@/data/calculators";
import { useSiteSettings } from "@/hooks/use-site-settings"; // Import useSiteSettings

export function Header() {
  const { isAuthenticated, user, logout } = useAuth();
  const { siteName, isLoading: isSiteSettingsLoading } = useSiteSettings(); // Get siteName from context

  const currentSiteName = isSiteSettingsLoading ? "CalcVerse" : siteName;


  const handleAuthSuccess = () => {
    // This function can be called by LoginModal/RegisterModal after successful auth
    // to trigger any re-renders or state updates needed in the header if necessary.
    // For now, useAuth hook handles global state, so this might not be strictly needed here
    // unless specific header re-rendering logic is required immediately.
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-20 max-w-screen-2xl items-center justify-between">
        <Link href="/" className="flex items-center space-x-2">
          <Atom className="h-8 w-8 text-primary" />
          <span className="font-headline text-2xl font-bold text-primary">{currentSiteName}</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-4 lg:space-x-6">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-base">
                Calculators <ChevronDown className="ml-1 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuLabel>Categories</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                {CATEGORIES.slice(0, 6).map((category) => ( 
                  <DropdownMenuItem key={category.id} asChild>
                    <Link href={`/categories/${category.slug}`} className="flex items-center">
                      <category.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                      <span>{category.name}</span>
                    </Link>
                  </DropdownMenuItem>
                ))}
                {CATEGORIES.length > 6 && (
                    <DropdownMenuItem asChild>
                         <Link href="/#categories" className="flex items-center"> 
                            <LayoutGrid className="mr-2 h-4 w-4 text-muted-foreground" />
                            <span>More Categories...</span>
                        </Link>
                    </DropdownMenuItem>
                )}
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
          {isAuthenticated && user?.username === 'admin' && ( // Show Admin link only if logged in as admin
             <Button variant="ghost" className="text-base" asChild>
                <Link href="/admin/dashboard">Admin Panel</Link>
            </Button>
          )}
        </nav>

        <div className="flex items-center space-x-3">
          <ThemeToggle />
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={`https://placehold.co/40x40.png?text=${user?.username?.[0]?.toUpperCase() || 'U'}`} alt={user?.username || "User"} data-ai-hint="avatar user" />
                    <AvatarFallback>{user?.username?.[0]?.toUpperCase() || "U"}</AvatarFallback>
                  </Avatar>
                  <span className="hidden sm:inline">{user?.username || "Profile"}</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem disabled>
                  <UserCircle className="mr-2 h-4 w-4" />
                  <span>View Profile</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center space-x-2">
              <LoginModal 
                trigger={
                  <Button variant="outline" className="hidden sm:inline-flex">
                    <LogIn className="mr-2 h-4 w-4" /> Login
                  </Button>
                } 
                onLoginSuccess={handleAuthSuccess}
              />
               <LoginModal 
                trigger={
                  <Button variant="ghost" size="icon" className="sm:hidden inline-flex" aria-label="Login">
                    <LogIn className="h-5 w-5" />
                  </Button>
                } 
                onLoginSuccess={handleAuthSuccess}
              />
              <RegisterModal 
                trigger={
                  <Button className="hidden sm:inline-flex">
                    <UserPlus className="mr-2 h-4 w-4" /> Register
                  </Button>
                }
                onRegisterSuccess={handleAuthSuccess}
              />
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
