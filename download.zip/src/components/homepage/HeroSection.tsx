
"use client";

import { useState, useEffect, useTransition } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Sparkles, Loader2 } from 'lucide-react';
import { ALL_CALCULATORS } from '@/data/calculators'; // Removed getCalculatorByAiName as it's not directly used here now
import type { Calculator } from '@/types/calculators';
import Link from 'next/link';
import { AISuggestionModal } from './AISuggestionModal';
import { getAISuggestion, type AISuggestionResult } from '@/app/actions';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent } from '../ui/card';

export function HeroSection() {
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<Calculator[]>([]);
  const [aiSuggestion, setAiSuggestion] = useState<AISuggestionResult | null>(null);
  const [isAiLoading, startAiTransition] = useTransition();
  const { toast } = useToast();
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    if (searchTerm.length > 1) {
      const filtered = ALL_CALCULATORS.filter(calc =>
        calc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        calc.keywords?.some(keyword => keyword.toLowerCase().includes(searchTerm.toLowerCase()))
      ).slice(0, 5); // Limit to 5 suggestions
      setSuggestions(filtered);
      setAiSuggestion(null); // Clear AI suggestion when typing for direct search
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchTerm]);

  const handleAiSearch = () => {
    if (!searchTerm.trim()) {
      toast({ title: "AI Search", description: "Please enter a search term for AI.", variant: "default"});
      return;
    }
    startAiTransition(async () => {
      setSuggestions([]); // Clear regular suggestions
      setAiSuggestion(null); // Clear previous AI suggestion
      setShowSuggestions(true); // Keep suggestion box open
      const result = await getAISuggestion(searchTerm);
      if ("error" in result) {
        toast({ title: "AI Suggestion Error", description: result.error, variant: "destructive" });
        setAiSuggestion(null);
      } else {
        setAiSuggestion(result);
      }
    });
  };
  
  const handleSuggestionClick = () => {
    // Clear search term and hide suggestions when a suggestion is clicked
    setSearchTerm('');
    setShowSuggestions(false);
    setAiSuggestion(null);
    setSuggestions([]);
  };


  return (
    <section className="py-20 md:py-32 bg-gradient-to-br from-primary/10 via-background to-background text-center">
      <div className="container mx-auto px-4">
        <h1 className="font-headline text-4xl md:text-6xl font-extrabold mb-6 text-primary drop-shadow-md">
          Calculate Anything.
        </h1>
        <h2 className="font-headline text-4xl md:text-6xl font-extrabold mb-10 text-foreground drop-shadow-md">
          Instantly. <span className="text-accent">Smartly.</span>
        </h2>
        <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
          Welcome to CalcVerse, your universe of calculators. Find tools for finance, health, education, and more, all in one place.
        </p>
        
        <div className="max-w-2xl mx-auto relative">
          <div className="flex gap-2 items-center">
            <div className="relative flex-grow">
              <Input
                type="search"
                placeholder="Search or ask AI (e.g., 'EMI', 'how old am I?')..."
                className="w-full h-14 pl-12 pr-4 text-lg rounded-lg shadow-lg focus:ring-2 focus:ring-primary"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onFocus={() => searchTerm.length > 1 && setShowSuggestions(true)}
                aria-label="Search calculators"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-6 w-6 text-muted-foreground" />
            </div>
            <Button 
              size="lg" 
              className="h-14 text-lg bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg shadow-lg px-4"
              onClick={handleAiSearch}
              disabled={isAiLoading}
              aria-label="Search with AI"
            >
              {isAiLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Sparkles className="h-5 w-5" />}
              <span className="ml-2 hidden sm:inline">AI Search</span>
            </Button>
          </div>

          {showSuggestions && (searchTerm.length > 1 || isAiLoading || aiSuggestion) && (
            <Card className="absolute mt-2 w-full text-left shadow-xl z-10 max-h-96 overflow-y-auto border border-border">
              <CardContent className="p-2">
                {isAiLoading && (
                  <div className="p-4 flex items-center justify-center text-muted-foreground">
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" /> AI is thinking...
                  </div>
                )}
                {!isAiLoading && aiSuggestion && (
                  <div className="p-3 border-b last:border-b-0 hover:bg-secondary/50 transition-colors rounded-md">
                    <p className="font-semibold text-accent flex items-center mb-1"><Sparkles className="h-4 w-4 mr-1.5" /> AI Suggestion:</p>
                    <h4 className="font-medium">{aiSuggestion.calculatorName}</h4>
                    <p className="text-sm text-muted-foreground mb-1.5">{aiSuggestion.reason}</p>
                    {aiSuggestion.slug ? (
                      <Button variant="link" size="sm" asChild className="p-0 h-auto text-primary text-sm" onClick={handleSuggestionClick}>
                        <Link href={`/calculators/${aiSuggestion.slug}`}>
                          Go to {aiSuggestion.calculatorName}
                        </Link>
                      </Button>
                    ): (
                        <span className="text-xs text-muted-foreground italic">This calculator cannot be directly linked.</span>
                    )}
                  </div>
                )}
                {!isAiLoading && !aiSuggestion && suggestions.length > 0 && (
                  <>
                  <p className="text-xs font-medium text-muted-foreground px-3 pt-2 pb-1">Direct Matches:</p>
                  <ul className="space-y-0.5">
                    {suggestions.map((calc) => (
                      <li key={calc.id}>
                        <Link
                          href={`/calculators/${calc.slug}`}
                          className="block p-3 hover:bg-secondary/50 transition-colors rounded-md"
                          onClick={handleSuggestionClick}
                        >
                          <div className="font-medium text-sm">{calc.name}</div>
                          <div className="text-xs text-muted-foreground line-clamp-1">{calc.description}</div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                  </>
                )}
                {!isAiLoading && !aiSuggestion && suggestions.length === 0 && searchTerm.length > 1 && (
                  <div className="p-4 text-center text-sm text-muted-foreground">
                    No direct matches. Try a broader term or use AI Search.
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
        
        <div className="mt-10">
          <AISuggestionModal 
            trigger={
              <Button variant="link" className="text-primary hover:text-primary/80 text-base">
                <Sparkles className="mr-2 h-4 w-4" /> Or, get a suggestion from our AI Assistant
              </Button>
            }
          />
        </div>
      </div>
    </section>
  );
}
