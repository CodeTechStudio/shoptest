"use client";

import { useState, useTransition } from 'react';
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sparkles, Loader2, Search } from "lucide-react";
import { getAISuggestion, type AISuggestionResult } from "@/app/actions";
import { useToast } from "@/hooks/use-toast";
import Link from 'next/link';
import { Badge } from '../ui/badge';

interface AISuggestionModalProps {
  trigger?: React.ReactNode;
}

export function AISuggestionModal({ trigger }: AISuggestionModalProps) {
  const [query, setQuery] = useState("");
  const [suggestion, setSuggestion] = useState<AISuggestionResult | null>(null);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  const handleSubmit = async () => {
    if (!query.trim()) {
      toast({
        title: "Error",
        description: "Please enter your query.",
        variant: "destructive",
      });
      return;
    }

    startTransition(async () => {
      setSuggestion(null);
      const result = await getAISuggestion(query);
      if ("error" in result) {
        toast({
          title: "AI Suggestion Error",
          description: result.error,
          variant: "destructive",
        });
      } else {
        setSuggestion(result);
      }
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline">
            <Sparkles className="mr-2 h-4 w-4" /> AI Suggestion
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Sparkles className="mr-2 h-5 w-5 text-primary" /> AI Calculator Assistant
          </DialogTitle>
          <DialogDescription>
            Describe what you want to calculate, and I'll suggest the best tool for the job.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="ai-query" className="text-right">
              Query
            </Label>
            <Input
              id="ai-query"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g., 'How old am I?' or 'Convert USD to EUR'"
              className="col-span-3"
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !isPending) {
                  handleSubmit();
                }
              }}
            />
          </div>
        </div>
        {isPending && (
          <div className="flex items-center justify-center my-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-2 text-muted-foreground">Getting suggestion...</p>
          </div>
        )}
        {suggestion && !isPending && (
          <div className="mt-4 p-4 border rounded-md bg-secondary/30">
            <h4 className="font-semibold text-lg mb-1">{suggestion.calculatorName}</h4>
            <p className="text-sm text-muted-foreground mb-3">{suggestion.reason}</p>
            {suggestion.slug ? (
              <Button asChild onClick={() => setIsOpen(false)}>
                <Link href={`/calculators/${suggestion.slug}`}>
                  Go to {suggestion.calculatorName}
                </Link>
              </Button>
            ) : (
              <Badge variant="outline">Calculator not directly linkable</Badge>
            )}
          </div>
        )}
        <DialogFooter>
          <Button onClick={handleSubmit} disabled={isPending}>
            {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
            Get Suggestion
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
