import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { getFeaturedCalculators } from '@/data/calculators';
import type { Calculator } from '@/types/calculators';

export function FeaturedCalculators() {
  const featuredCalculators = getFeaturedCalculators();

  if (featuredCalculators.length === 0) {
    return null;
  }

  return (
    <section className="py-16 bg-secondary/20 dark:bg-secondary/10">
      <div className="container mx-auto px-4">
        <h2 className="font-headline text-3xl font-bold text-center mb-12 text-foreground">
          Featured Calculators
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredCalculators.map((calculator: Calculator) => (
            <Card key={calculator.id} className="flex flex-col shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-2">
                  <calculator.icon className="h-8 w-8 text-primary" aria-hidden="true" />
                  <CardTitle className="text-2xl font-semibold text-foreground">{calculator.name}</CardTitle>
                </div>
                <CardDescription className="h-12 overflow-hidden">{calculator.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                {/* Additional content or features can be listed here */}
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Link href={`/calculators/${calculator.slug}`}>Use Now</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
