
"use client";

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CATEGORIES } from '@/data/calculators';
import type { Category } from '@/types/calculators';
import { Button } from '../ui/button';
import { ArrowRight } from 'lucide-react';

export function CategoryGrid() {
  return (
    <section id="categories" className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
            <h2 className="font-headline text-3xl md:text-4xl font-bold text-foreground">
            Explore Calculator Categories
            </h2>
            <p className="text-lg text-muted-foreground mt-2 max-w-xl mx-auto">
                Find the perfect tool from our diverse range of calculators.
            </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {CATEGORIES.map((category: Category) => (
            <Link
              href={`/categories/${category.slug}`}
              key={category.id}
              className="block group"
            >
              <Card className="h-full flex flex-col justify-between shadow-lg hover:shadow-xl transition-all duration-300 bg-card hover:border-primary/50 border-2 border-transparent transform hover:-translate-y-1">
                <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
                  <div className="space-y-1">
                    <CardTitle className="text-xl font-semibold text-card-foreground group-hover:text-primary transition-colors">
                      {category.name}
                    </CardTitle>
                     {typeof category.calculatorCount === 'number' && category.calculatorCount > 0 && (
                        <Badge variant="secondary" className="font-normal group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                        {category.calculatorCount} Calculator{category.calculatorCount > 1 ? 's' : ''}
                        </Badge>
                    )}
                  </div>
                  <category.icon className="h-10 w-10 text-primary/70 group-hover:text-primary transition-colors flex-shrink-0" aria-hidden="true" />
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground h-12 overflow-hidden">
                    {category.description || `Explore calculators for ${category.name.toLowerCase()}.`}
                  </p>
                </CardContent>
                 <div className="p-4 pt-2">
                    <Button variant="ghost" size="sm" className="text-primary group-hover:underline p-0 h-auto">
                        View Category <ArrowRight className="ml-1.5 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                 </div>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
