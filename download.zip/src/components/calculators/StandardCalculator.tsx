
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Minus, X, Divide, Percent, Delete, Sigma, Equal } from 'lucide-react';

export function StandardCalculator() {
  const [displayValue, setDisplayValue] = useState<string>("0");
  const [operand, setOperand] = useState<number | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState<boolean>(false);
  const [memory, setMemory] = useState<number>(0);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleDigitClick = (digit: string) => {
    if (waitingForOperand) {
      setDisplayValue(digit);
      setWaitingForOperand(false);
    } else {
      setDisplayValue(displayValue === "0" ? digit : displayValue + digit);
    }
  };

  const handleDecimalClick = () => {
    if (waitingForOperand) {
      setDisplayValue("0.");
      setWaitingForOperand(false);
    } else if (!displayValue.includes(".")) {
      setDisplayValue(displayValue + ".");
    }
  };

  const handleOperatorClick = (nextOperator: string) => {
    const inputValue = parseFloat(displayValue);

    if (operand === null) {
      setOperand(inputValue);
    } else if (operator) {
      const result = calculate(operand, inputValue, operator);
      setDisplayValue(String(result));
      setOperand(result);
    }

    setWaitingForOperand(true);
    setOperator(nextOperator);
  };

  const calculate = (prevOperand: number, currentOperand: number, op: string): number => {
    // Handle potential NaN issues if inputs are not numbers
    if (isNaN(prevOperand) || isNaN(currentOperand)) return NaN;
    switch (op) {
      case '+': return prevOperand + currentOperand;
      case '-': return prevOperand - currentOperand;
      case '*': return prevOperand * currentOperand;
      case '/': return currentOperand === 0 ? Infinity : prevOperand / currentOperand;
      default: return currentOperand;
    }
  };

  const handleEqualsClick = () => {
    const inputValue = parseFloat(displayValue);
    if (operator && operand !== null) {
      const result = calculate(operand, inputValue, operator);
      setDisplayValue(String(result));
      setOperand(null); // Reset operand for new calculation sequence
      setOperator(null); // Reset operator
      setWaitingForOperand(true); // Ready for new input, or chain calculation if user presses another operator
    }
  };

  const handleClearClick = () => {
    setDisplayValue("0");
    setOperand(null);
    setOperator(null);
    setWaitingForOperand(false);
  };
  
  const handleBackspaceClick = () => {
    if (waitingForOperand) return; 
    if (displayValue.length > 1) {
      setDisplayValue(displayValue.slice(0, -1));
    } else {
      setDisplayValue("0");
    }
  };

  const handlePercentageClick = () => {
    const currentValue = parseFloat(displayValue);
    if (isNaN(currentValue)) return;

    if (operand !== null && operator && !isNaN(operand)) {
      let percentageValue;
      if (operator === '+' || operator === '-') {
        percentageValue = (currentValue / 100) * operand;
      } else if (operator === '*' || operator === '/') {
         percentageValue = currentValue / 100;
      } else {
        percentageValue = currentValue / 100;
      }
      setDisplayValue(String(percentageValue));
    } else {
       setDisplayValue(String(currentValue / 100));
    }
    setWaitingForOperand(true); 
  };

  const handleMemoryClear = () => setMemory(0);
  const handleMemoryRecall = () => {
    setDisplayValue(String(memory));
    setWaitingForOperand(false); // Allow editing recalled number
  };
  const handleMemoryAdd = () => {
    const currentValue = parseFloat(displayValue);
    if (!isNaN(currentValue)) setMemory(memory + currentValue);
  };
  const handleMemorySubtract = () => {
    const currentValue = parseFloat(displayValue);
    if (!isNaN(currentValue)) setMemory(memory - currentValue);
  };

  useEffect(() => {
    if (!isClient) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key >= '0' && event.key <= '9') {
        handleDigitClick(event.key);
      } else if (event.key === '.') {
        handleDecimalClick();
      } else if (event.key === '+') {
        handleOperatorClick('+');
      } else if (event.key === '-') {
        handleOperatorClick('-');
      } else if (event.key === '*') {
        handleOperatorClick('*');
      } else if (event.key === '/') {
        handleOperatorClick('/');
      } else if (event.key === 'Enter' || event.key === '=') {
        event.preventDefault(); 
        handleEqualsClick();
      } else if (event.key === 'Escape') {
        handleClearClick();
      } else if (event.key === 'Backspace') {
        handleBackspaceClick();
      } else if (event.key === '%') {
        handlePercentageClick();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isClient, displayValue, operand, operator, waitingForOperand, memory]); // Ensure all state dependencies are here

  if (!isClient) {
    return null; // Or a loading skeleton
  }

  const buttonClass = "text-xl h-16 w-full transition-all duration-150 ease-in-out focus:ring-2 focus:ring-primary focus:z-10 rounded-md";
  const operatorButtonClass = `${buttonClass} bg-secondary hover:bg-secondary/80 text-secondary-foreground dark:bg-secondary dark:hover:bg-secondary/90`;
  const specialButtonClass = `${buttonClass} bg-muted hover:bg-muted/80 text-muted-foreground dark:bg-muted dark:hover:bg-muted/90`;
  const numberButtonClass = `${buttonClass} bg-card hover:bg-accent/20 dark:bg-card dark:hover:bg-accent/30 border border-border`;
  const equalsButtonClass = `${buttonClass} bg-primary hover:bg-primary/90 text-primary-foreground`;


  return (
    <Card className="max-w-xs mx-auto shadow-2xl overflow-hidden border-2 border-primary/20">
      <CardContent className="p-3 space-y-3">
        <Input
          type="text"
          value={displayValue}
          readOnly
          className="w-full h-20 text-5xl text-right bg-background dark:bg-muted/30 rounded-md p-4 focus:ring-0 focus-visible:ring-0 border-border text-foreground"
          aria-label="Calculator display"
          style={{ fontFamily: 'var(--font-code)' }}
        />
        <div className="grid grid-cols-4 gap-2">
          <Button onClick={handleMemoryClear} className={specialButtonClass} aria-label="Memory Clear">MC</Button>
          <Button onClick={handleMemoryRecall} className={specialButtonClass} aria-label="Memory Recall">MR</Button>
          <Button onClick={handleMemoryAdd} className={specialButtonClass} aria-label="Memory Add">M+</Button>
          <Button onClick={handleMemorySubtract} className={specialButtonClass} aria-label="Memory Subtract">M-</Button>

          <Button onClick={handleClearClick} className={`${specialButtonClass} col-span-2`} aria-label="Clear All">C</Button>
          <Button onClick={handleBackspaceClick} className={specialButtonClass} aria-label="Backspace"><Delete size={24}/></Button>
          <Button onClick={() => handleOperatorClick('/')} className={operatorButtonClass} aria-label="Divide"><Divide size={24}/></Button>

          {['7', '8', '9'].map(digit => (
            <Button key={digit} onClick={() => handleDigitClick(digit)} className={numberButtonClass}>{digit}</Button>
          ))}
          <Button onClick={() => handleOperatorClick('*')} className={operatorButtonClass} aria-label="Multiply"><X size={24}/></Button>

          {['4', '5', '6'].map(digit => (
            <Button key={digit} onClick={() => handleDigitClick(digit)} className={numberButtonClass}>{digit}</Button>
          ))}
          <Button onClick={() => handleOperatorClick('-')} className={operatorButtonClass} aria-label="Subtract"><Minus size={24}/></Button>

          {['1', '2', '3'].map(digit => (
            <Button key={digit} onClick={() => handleDigitClick(digit)} className={numberButtonClass}>{digit}</Button>
          ))}
          <Button onClick={() => handleOperatorClick('+')} className={operatorButtonClass} aria-label="Add"><Plus size={24}/></Button>

          <Button onClick={() => handleDigitClick('0')} className={`${numberButtonClass} col-span-2`}>0</Button>
          <Button onClick={handleDecimalClick} className={numberButtonClass} aria-label="Decimal">.</Button>
          <Button onClick={handlePercentageClick} className={specialButtonClass} aria-label="Percentage"><Percent size={24}/></Button>
        </div>
         <Button onClick={handleEqualsClick} className={`${equalsButtonClass} w-full h-16 text-2xl`} aria-label="Equals">
            <Equal size={28} />
          </Button>
      </CardContent>
    </Card>
  );
}
