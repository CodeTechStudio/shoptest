
"use client";

import React from 'react';

export function PlaceholderCalculator(): JSX.Element {
  return (
    <div className="text-center py-10 text-muted-foreground">
      Calculator component coming soon!
    </div>
  );
}
