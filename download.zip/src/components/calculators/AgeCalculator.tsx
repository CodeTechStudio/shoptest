
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { CalendarIcon, Gift, RefreshCw } from 'lucide-react';
import { 
  format, 
  differenceInYears, 
  differenceInMonths, 
  differenceInDays, 
  addYears, 
  addMonths as addMonthsDateFns, 
  isValid,
  isPast,
  isToday,
  setYear,
  setMonth,
  setDate,
  isBefore,
  isSameDay
} from 'date-fns';

interface AgeResult {
  years: number;
  months: number;
  days: number;
  nextBirthdayInDays?: number; // Made optional as it might not always be relevant if targetDate is far in past/future
  nextBirthdayDate?: Date;
}

export function AgeCalculator() {
  const [birthDate, setBirthDate] = useState<Date | undefined>(undefined);
  const [targetDate, setTargetDate] = useState<Date | undefined>(new Date());
  const [ageResult, setAgeResult] = useState<AgeResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    // Set targetDate to ensure it's a fresh Date object on client mount, avoiding hydration issues with new Date() directly in useState
    setTargetDate(new Date()); 
  }, []);

  const calculateAge = () => {
    if (!isClient) return;

    if (!birthDate || !isValid(birthDate)) {
      setError("Please select a valid birth date.");
      setAgeResult(null);
      return;
    }
    if (!targetDate || !isValid(targetDate)) {
      setError("Please select a valid 'age at date of'.");
      setAgeResult(null);
      return;
    }

    if (isBefore(targetDate, birthDate)) {
      setError("'Age at date of' cannot be before birth date.");
      setAgeResult(null);
      return;
    }
    setError(null);

    // Calculate age based on birthDate and targetDate
    const years = differenceInYears(targetDate, birthDate);
    const dateAfterYears = addYears(birthDate, years);
    const months = differenceInMonths(targetDate, dateAfterYears);
    const dateAfterYearsAndMonths = addMonthsDateFns(dateAfterYears, months);
    const days = differenceInDays(targetDate, dateAfterYearsAndMonths);
    
    // Calculate next birthday based on actual current date
    const today = new Date();
    let nextBirthdayFullDate: Date | undefined;
    let nextBirthdayInDays: number | undefined;

    // Only calculate next birthday if birthDate is in the past or today relative to actual today
    if (isBefore(birthDate, today) || isSameDay(birthDate, today)) {
        const currentActualYear = today.getFullYear();
        const birthMonth = birthDate.getMonth();
        const birthDayOfMonth = birthDate.getDate();

        let nextBirthdayThisYear = setDate(setMonth(new Date(), birthMonth), birthDayOfMonth);
        nextBirthdayThisYear = setYear(nextBirthdayThisYear, currentActualYear);

        if (isBefore(nextBirthdayThisYear, today) && !isSameDay(nextBirthdayThisYear, today)) {
            nextBirthdayFullDate = addYears(nextBirthdayThisYear, 1);
        } else {
            nextBirthdayFullDate = nextBirthdayThisYear;
        }
        nextBirthdayInDays = differenceInDays(nextBirthdayFullDate, today);
    }
    
    setAgeResult({ years, months, days, nextBirthdayInDays, nextBirthdayDate: nextBirthdayFullDate });
  };

  const resetCalculator = () => {
    setBirthDate(undefined);
    setTargetDate(new Date());
    setAgeResult(null);
    setError(null);
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-primary/20">
      <CardContent className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
          <div>
            <Label htmlFor="birthdate-picker" className="block text-sm font-medium text-foreground mb-1">
              Date of Birth
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="birthdate-picker"
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal h-12 text-base border-input hover:bg-accent/50",
                    !birthDate && "text-muted-foreground"
                  )}
                  aria-label="Pick a birth date"
                >
                  <CalendarIcon className="mr-3 h-5 w-5 text-primary" />
                  {birthDate ? format(birthDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={birthDate}
                  onSelect={(date) => {
                    setBirthDate(date);
                    setAgeResult(null); 
                    setError(null);
                  }}
                  defaultMonth={birthDate || new Date(new Date().setFullYear(new Date().getFullYear() - 20))} // Default to 20 years ago
                  captionLayout="dropdown-buttons"
                  fromYear={1900}
                  toYear={new Date().getFullYear()}
                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                />
              </PopoverContent>
            </Popover>
          </div>
          <div>
            <Label htmlFor="targetdate-picker" className="block text-sm font-medium text-foreground mb-1">
              Age at Date of
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="targetdate-picker"
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal h-12 text-base border-input hover:bg-accent/50",
                    !targetDate && "text-muted-foreground"
                  )}
                  aria-label="Pick a target date"
                >
                  <CalendarIcon className="mr-3 h-5 w-5 text-primary" />
                  {targetDate ? format(targetDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={targetDate}
                  onSelect={(date) => {
                    setTargetDate(date);
                    setAgeResult(null);
                    setError(null);
                  }}
                  defaultMonth={targetDate || new Date()}
                  captionLayout="dropdown-buttons"
                  fromYear={1900}
                  toYear={new Date().getFullYear() + 100} // Allow future dates
                  disabled={(date) => birthDate ? isBefore(date, birthDate) : false}
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {ageResult && !error && (
          <div className="space-y-4 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center mb-4">
              Calculated Age {targetDate && !isSameDay(targetDate, new Date()) ? `as of ${format(targetDate, "PPP")}` : ''}
            </h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="text-4xl font-bold text-foreground">{ageResult.years}</p>
                <p className="text-sm text-muted-foreground">Years</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-foreground">{ageResult.months}</p>
                <p className="text-sm text-muted-foreground">Months</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-foreground">{ageResult.days}</p>
                <p className="text-sm text-muted-foreground">Days</p>
              </div>
            </div>

            {ageResult.nextBirthdayDate && ageResult.nextBirthdayInDays !== undefined && (
                 <div className="text-center pt-4 border-t mt-6 border-border/50">
                 <p className="text-lg font-medium text-foreground flex items-center justify-center">
                   <Gift className="h-6 w-6 mr-2 text-accent" />
                   Next Birthday (from today)
                 </p>
                 <p className="text-base text-muted-foreground mt-1">
                   {format(ageResult.nextBirthdayDate, "EEEE, MMMM do, yyyy")}
                 </p>
                 <p className="text-base text-muted-foreground">
                   (in {ageResult.nextBirthdayInDays} day{ageResult.nextBirthdayInDays !== 1 ? 's' : ''})
                 </p>
               </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateAge} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          Calculate Age
        </Button>
      </CardFooter>
    </Card>
  );
}

