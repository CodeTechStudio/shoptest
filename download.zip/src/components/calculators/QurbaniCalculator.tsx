
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RefreshCw, Users, AlertTriangle } from 'lucide-react';

interface QurbaniResult {
  costPerShare: number;
}

export function QurbaniCalculator() {
  const [totalAnimalCost, setTotalAnimalCost] = useState<string>("");
  const [numberOfShares, setNumberOfShares] = useState<string>("7"); // Default to 7 for larger animals

  const [result, setResult] = useState<QurbaniResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateQurbani = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const cost = parseFloat(totalAnimalCost);
    const shares = parseInt(numberOfShares, 10);

    if (isNaN(cost) || cost <= 0) {
      setError("Please enter a valid total animal cost.");
      return;
    }
    if (isNaN(shares) || shares <= 0) {
      setError("Please enter a valid number of shares (must be 1 or more).");
      return;
    }

    const costPerShare = cost / shares;

    setResult({
      costPerShare: parseFloat(costPerShare.toFixed(2)),
    });
  };

  const resetCalculator = () => {
    setTotalAnimalCost("");
    setNumberOfShares("7");
    setResult(null);
    setError(null);
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-md mx-auto shadow-lg border-primary/20">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-primary flex items-center">
            <Users className="mr-2 h-7 w-7" /> Qurbani Share Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-2">
          <Label htmlFor="totalAnimalCost" className="text-sm font-medium text-foreground">Total Animal Cost (₹)</Label>
          <Input
            id="totalAnimalCost"
            type="number"
            value={totalAnimalCost}
            onChange={(e) => setTotalAnimalCost(e.target.value)}
            placeholder="e.g., 35000"
            className="h-12 text-base"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="numberOfShares" className="text-sm font-medium text-foreground">Number of Shares</Label>
          <Input
            id="numberOfShares"
            type="number"
            value={numberOfShares}
            onChange={(e) => setNumberOfShares(e.target.value)}
            placeholder="e.g., 1 or 7"
            className="h-12 text-base"
          />
           <p className="text-xs text-muted-foreground mt-1">Typically 1 for goat/sheep, 7 for cow/camel.</p>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2" /> {error}
          </p>
        )}

        {result && !error && (
          <div className="space-y-3 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-xl font-semibold text-primary text-center">Qurbani Share Cost</h3>
            <div className="flex justify-center items-baseline text-4xl font-bold text-foreground">
              <span>₹</span>{result.costPerShare.toLocaleString()}
              <span className="text-lg text-muted-foreground ml-1">/ share</span>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateQurbani} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          Calculate Share Cost
        </Button>
      </CardFooter>
    </Card>
  );
}
