
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RefreshCw, CalendarX, AlertTriangle } from 'lucide-react';

interface FidyaResult {
  totalFidya: number;
}

export function MissedFastCalculator() {
  const [missedFasts, setMissedFasts] = useState<string>("");
  const [fidyaPerFast, setFidyaPerFast] = useState<string>("");

  const [result, setResult] = useState<FidyaResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateFidya = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const fasts = parseInt(missedFasts, 10);
    const fidyaAmount = parseFloat(fidyaPerFast);

    if (isNaN(fasts) || fasts < 0) {
      setError("Please enter a valid number of missed fasts (0 or more).");
      return;
    }
    if (isNaN(fidyaAmount) || fidyaAmount <= 0) {
      setError("Please enter a valid Fidya amount per fast.");
      return;
    }

    const totalFidya = fasts * fidyaAmount;

    setResult({
      totalFidya: parseFloat(totalFidya.toFixed(2)),
    });
  };

  const resetCalculator = () => {
    setMissedFasts("");
    setFidyaPerFast("");
    setResult(null);
    setError(null);
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-md mx-auto shadow-lg border-primary/20">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-primary flex items-center">
            <CalendarX className="mr-2 h-7 w-7" /> Missed Fasts (Roza) Fidya Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-2">
          <Label htmlFor="missedFasts" className="text-sm font-medium text-foreground">Number of Missed Fasts</Label>
          <Input
            id="missedFasts"
            type="number"
            value={missedFasts}
            onChange={(e) => setMissedFasts(e.target.value)}
            placeholder="e.g., 5"
            className="h-12 text-base"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="fidyaPerFast" className="text-sm font-medium text-foreground">Fidya Amount per Fast (₹)</Label>
          <Input
            id="fidyaPerFast"
            type="number"
            value={fidyaPerFast}
            onChange={(e) => setFidyaPerFast(e.target.value)}
            placeholder="e.g., 100"
            className="h-12 text-base"
          />
          <p className="text-xs text-muted-foreground mt-1">Consult a local scholar for the current Fidya rate in your area.</p>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2" /> {error}
          </p>
        )}

        {result && !error && (
          <div className="space-y-3 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-xl font-semibold text-primary text-center">Total Fidya Payable</h3>
            <div className="flex justify-center items-baseline text-4xl font-bold text-foreground">
              <span>₹</span>{result.totalFidya.toLocaleString()}
            </div>
             {parseInt(missedFasts, 10) === 0 && (
                <p className="text-sm text-center text-muted-foreground pt-2">
                    No missed fasts entered, so no Fidya is due.
                </p>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateFidya} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          Calculate Fidya
        </Button>
      </CardFooter>
    </Card>
  );
}
