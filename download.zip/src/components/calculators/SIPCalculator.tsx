
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RefreshCw, TrendingUp as TrendingUpIcon, BarChartHorizontalBig } from 'lucide-react';
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, CartesianGrid, XAxis, YAxis, Bar, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface SIPResult {
  investedAmount: number;
  estimatedReturns: number;
  totalValue: number;
  monthlyData: { month: number; value: number; invested: number }[];
}

const chartConfig = {
  totalValue: { label: "Total Value", color: "hsl(var(--chart-1))" },
  investedAmount: { label: "Invested Amount", color: "hsl(var(--chart-2))" },
} satisfies ChartConfig;


export function SIPCalculator() {
  const [monthlyInvestment, setMonthlyInvestment] = useState<string>("");
  const [annualReturnRate, setAnnualReturnRate] = useState<string>("");
  const [investmentPeriod, setInvestmentPeriod] = useState<string>(""); // In years
  const [result, setResult] = useState<SIPResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateSIP = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const M = parseFloat(monthlyInvestment); // Monthly investment
    const annualRate = parseFloat(annualReturnRate); // Annual rate of return
    const T = parseInt(investmentPeriod, 10); // Investment period in years

    if (isNaN(M) || M <= 0) {
      setError("Please enter a valid monthly investment amount.");
      return;
    }
    if (isNaN(annualRate) || annualRate < 0) { // Allow 0% return rate
      setError("Please enter a valid expected annual return rate.");
      return;
    }
    if (isNaN(T) || T <= 0) {
      setError("Please enter a valid investment period in years.");
      return;
    }

    const i = annualRate / 12 / 100; // Monthly rate of return
    const n = T * 12; // Number of months

    let totalValue = 0;
    let investedAmount = 0;
    const monthlyData: { month: number; value: number; invested: number }[] = [];

    if (annualRate === 0) { // Handle 0% return rate case
        totalValue = M * n;
        investedAmount = M * n;
        for (let month = 1; month <= n; month++) {
            monthlyData.push({ month, value: M * month, invested: M * month });
        }
    } else {
        // Future Value of a series formula for SIP: M * [((1+i)^n - 1) / i] * (1+i)
        // However, to get monthly data, it's better to iterate.
        let currentVal = 0;
        for (let month = 1; month <= n; month++) {
            currentVal = (currentVal + M) * (1 + i);
            investedAmount += M;
            monthlyData.push({ month, value: parseFloat(currentVal.toFixed(2)), invested: parseFloat(investedAmount.toFixed(2)) });
        }
        totalValue = currentVal;
    }
    
    const estimatedReturns = totalValue - (M * n);

    setResult({
      investedAmount: parseFloat((M * n).toFixed(2)),
      estimatedReturns: parseFloat(estimatedReturns.toFixed(2)),
      totalValue: parseFloat(totalValue.toFixed(2)),
      monthlyData,
    });
  };

  const resetCalculator = () => {
    setMonthlyInvestment("");
    setAnnualReturnRate("");
    setInvestmentPeriod("");
    setResult(null);
    setError(null);
  };
  
  const yAxisFormatter = (value: number) => {
    if (value >= 10000000) return `${(value / 10000000).toFixed(1)}Cr`; // Crores
    if (value >= 100000) return `${(value / 100000).toFixed(1)}L`; // Lakhs
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`; // Thousands
    return value.toString();
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-lg border-primary/20">
      <CardContent className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <Label htmlFor="monthlyInvestment" className="text-sm font-medium text-foreground">Monthly Investment (₹)</Label>
            <Input
              id="monthlyInvestment"
              type="number"
              value={monthlyInvestment}
              onChange={(e) => setMonthlyInvestment(e.target.value)}
              placeholder="e.g., 5000"
              className="h-12 text-base"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="annualReturnRate" className="text-sm font-medium text-foreground">Expected Return Rate (% p.a.)</Label>
            <Input
              id="annualReturnRate"
              type="number"
              value={annualReturnRate}
              onChange={(e) => setAnnualReturnRate(e.target.value)}
              placeholder="e.g., 12"
              className="h-12 text-base"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="investmentPeriod" className="text-sm font-medium text-foreground">Investment Period (Years)</Label>
            <Input
              id="investmentPeriod"
              type="number"
              value={investmentPeriod}
              onChange={(e) => setInvestmentPeriod(e.target.value)}
              placeholder="e.g., 10"
              className="h-12 text-base"
            />
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {result && !error && (
          <div className="space-y-6 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center">Investment Projection</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Invested Amount</p>
                <p className="text-2xl font-bold text-foreground">₹{result.investedAmount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Est. Returns</p>
                <p className="text-2xl font-bold text-foreground">₹{result.estimatedReturns.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Value</p>
                <p className="text-2xl font-bold text-foreground">₹{result.totalValue.toLocaleString()}</p>
              </div>
            </div>

            {result.monthlyData.length > 0 && (
                <div className="h-[300px] w-full mt-6">
                    <ChartContainer config={chartConfig} className="w-full h-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={result.monthlyData} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis 
                                  dataKey="month" 
                                  tickFormatter={(value, index) => (index + 1) % 12 === 0 || index === result.monthlyData.length - 1 || index === 0 ? `Yr ${Math.ceil((index+1)/12)}` : ""}
                                  tickLine={false}
                                  axisLine={false}
                                  interval="preserveStartEnd"
                                />
                                <YAxis tickFormatter={yAxisFormatter} axisLine={false} tickLine={false} width={80}/>
                                <Tooltip
                                    content={<ChartTooltipContent 
                                        formatter={(value, name) => (
                                            <div>
                                                <p>{name === 'totalValue' ? 'Total Value' : 'Invested'}: ₹{Number(value).toLocaleString()}</p>
                                            </div>
                                        )} 
                                    />} 
                                />
                                <Legend content={({ payload }) => <ChartLegendContent payload={payload} />} />
                                <Bar dataKey="investedAmount" fill={chartConfig.investedAmount.color} name="Invested Amount" stackId="a" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="value" fill={chartConfig.totalValue.color} name="Total Value" stackId="a" radius={[4, 4, 0, 0]} 
                                     barSize={20}
                                     itemStyle={{stroke: chartConfig.totalValue.color, strokeWidth:2}}
                                />
                            </BarChart>
                        </ResponsiveContainer>
                    </ChartContainer>
                </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateSIP} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          <TrendingUpIcon className="mr-2 h-4 w-4" /> Calculate SIP
        </Button>
      </CardFooter>
    </Card>
  );
}

    