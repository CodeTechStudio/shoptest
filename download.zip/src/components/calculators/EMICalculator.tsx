
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { RefreshCw, PieChartIcon, TrendingUp, Receipt } from 'lucide-react';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { PieChart, Pie, Cell, Tooltip } from 'recharts';
import { cn } from '@/lib/utils';

interface EMIResult {
  emi: number;
  totalInterest: number;
  totalPayment: number;
  principal: number;
}

const chartConfig = {
  principal: {
    label: "Principal",
    color: "hsl(var(--chart-1))",
  },
  interest: {
    label: "Total Interest",
    color: "hsl(var(--chart-2))",
  },
};

export function EMICalculator() {
  const [principal, setPrincipal] = useState<string>("");
  const [rate, setRate] = useState<string>("");
  const [tenure, setTenure] = useState<string>("");
  const [tenureUnit, setTenureUnit] = useState<"years" | "months">("years");
  const [result, setResult] = useState<EMIResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateEMI = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const p = parseFloat(principal);
    const annualRate = parseFloat(rate);
    let t = parseInt(tenure, 10);

    if (isNaN(p) || p <= 0) {
      setError("Please enter a valid principal amount.");
      return;
    }
    if (isNaN(annualRate) || annualRate <= 0) {
      setError("Please enter a valid annual interest rate.");
      return;
    }
    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid loan tenure.");
      return;
    }

    const monthlyRate = annualRate / 12 / 100;
    const numberOfMonths = tenureUnit === "years" ? t * 12 : t;

    if (monthlyRate === 0) { // Handle 0% interest rate separately
        const emi = p / numberOfMonths;
        setResult({
            emi: parseFloat(emi.toFixed(2)),
            totalInterest: 0,
            totalPayment: p,
            principal: p,
        });
        return;
    }

    const emi = (p * monthlyRate * Math.pow(1 + monthlyRate, numberOfMonths)) / (Math.pow(1 + monthlyRate, numberOfMonths) - 1);
    const totalPayment = emi * numberOfMonths;
    const totalInterest = totalPayment - p;

    if (isNaN(emi) || !isFinite(emi)) {
        setError("Could not calculate EMI. Please check your inputs.");
        return;
    }

    setResult({
      emi: parseFloat(emi.toFixed(2)),
      totalInterest: parseFloat(totalInterest.toFixed(2)),
      totalPayment: parseFloat(totalPayment.toFixed(2)),
      principal: p,
    });
  };

  const resetCalculator = () => {
    setPrincipal("");
    setRate("");
    setTenure("");
    setTenureUnit("years");
    setResult(null);
    setError(null);
  };

  const chartData = result
    ? [
        { name: 'Principal', value: result.principal, fill: chartConfig.principal.color },
        { name: 'Total Interest', value: result.totalInterest, fill: chartConfig.interest.color },
      ]
    : [];

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-lg border-primary/20">
      <CardContent className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="principal" className="text-sm font-medium text-foreground">Loan Amount (Principal)</Label>
            <Input
              id="principal"
              type="number"
              value={principal}
              onChange={(e) => setPrincipal(e.target.value)}
              placeholder="e.g., 100000"
              className="h-12 text-base"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="rate" className="text-sm font-medium text-foreground">Annual Interest Rate (%)</Label>
            <Input
              id="rate"
              type="number"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              placeholder="e.g., 10.5"
              className="h-12 text-base"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tenure" className="text-sm font-medium text-foreground">Loan Tenure</Label>
          <div className="flex items-center gap-3">
            <Input
              id="tenure"
              type="number"
              value={tenure}
              onChange={(e) => setTenure(e.target.value)}
              placeholder={tenureUnit === "years" ? "e.g., 5" : "e.g., 60"}
              className="h-12 text-base flex-grow"
            />
            <RadioGroup
              value={tenureUnit}
              onValueChange={(value: "years" | "months") => {
                setTenureUnit(value);
                setResult(null); // Reset result when unit changes
              }}
              className="flex"
            >
              <div className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50 cursor-pointer">
                <RadioGroupItem value="years" id="years" />
                <Label htmlFor="years" className="cursor-pointer">Years</Label>
              </div>
              <div className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50 cursor-pointer">
                <RadioGroupItem value="months" id="months" />
                <Label htmlFor="months" className="cursor-pointer">Months</Label>
              </div>
            </RadioGroup>
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {result && !error && (
          <div className="space-y-6 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center">Loan EMI Details</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Monthly EMI</p>
                <p className="text-2xl font-bold text-foreground">₹{result.emi.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Interest</p>
                <p className="text-2xl font-bold text-foreground">₹{result.totalInterest.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Payment</p>
                <p className="text-2xl font-bold text-foreground">₹{result.totalPayment.toLocaleString()}</p>
              </div>
            </div>

            {result.principal > 0 && result.totalInterest >= 0 && (
                 <div className="h-[250px] w-full mt-6">
                 <ChartContainer config={chartConfig} className="w-full h-full">
                   <PieChart accessibilityLayer>
                     <Tooltip
                       cursor={false}
                       content={<ChartTooltipContent hideLabel indicator="line" nameKey="name" />}
                     />
                     <Pie
                       data={chartData}
                       dataKey="value"
                       nameKey="name"
                       innerRadius={60}
                       strokeWidth={5}
                     >
                        {chartData.map((entry) => (
                            <Cell key={`cell-${entry.name}`} fill={entry.fill} />
                        ))}
                     </Pie>
                     <ChartLegend
                        content={<ChartLegendContent nameKey="name" />}
                        className="-translate-y-2 flex-wrap gap-2 [&>*]:basis-1/4 [&>*]:justify-center"
                      />
                   </PieChart>
                 </ChartContainer>
               </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateEMI} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          <Receipt className="mr-2 h-4 w-4" /> Calculate EMI
        </Button>
      </CardFooter>
    </Card>
  );
}

    