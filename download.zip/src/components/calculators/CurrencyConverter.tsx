
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Repeat, ArrowRightLeft } from 'lucide-react';

// Mock data - In a real app, fetch this from an API
const MOCK_CURRENCIES = [
  { code: "USD", name: "US Dollar" },
  { code: "EUR", name: "Euro" },
  { code: "GBP", name: "British Pound" },
  { code: "JPY", name: "Japanese Yen" },
  { code: "INR", name: "Indian Rupee" },
  { code: "AUD", name: "Australian Dollar" },
  { code: "CAD", name: "Canadian Dollar" },
];

// Mock exchange rates relative to USD
const MOCK_RATES: Record<string, number> = {
  USD: 1,
  EUR: 0.92, // 1 USD = 0.92 EUR
  GBP: 0.79, // 1 USD = 0.79 GBP
  JPY: 157.0, // 1 USD = 157 JPY
  INR: 83.5, // 1 USD = 83.5 INR
  AUD: 1.50, // 1 USD = 1.50 AUD
  CAD: 1.37, // 1 USD = 1.37 CAD
};

interface ConversionResult {
  fromCurrency: string;
  toCurrency: string;
  amount: number;
  convertedAmount: number;
  rateUsed: number;
}

export function CurrencyConverter() {
  const [amount, setAmount] = useState<string>("1");
  const [fromCurrency, setFromCurrency] = useState<string>("USD");
  const [toCurrency, setToCurrency] = useState<string>("INR");
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const convertCurrency = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < 0) {
      setError("Please enter a valid amount.");
      return;
    }
    if (!fromCurrency || !toCurrency) {
      setError("Please select both 'From' and 'To' currencies.");
      return;
    }
    if (fromCurrency === toCurrency) {
        setResult({
            fromCurrency,
            toCurrency,
            amount: amt,
            convertedAmount: amt,
            rateUsed: 1,
        });
        return;
    }

    // Mock conversion logic
    const rateFromUSD = MOCK_RATES[fromCurrency];
    const rateToUSD = MOCK_RATES[toCurrency];

    if (!rateFromUSD || !rateToUSD) {
        setError("Exchange rate not available for selected currencies (mock data).");
        return;
    }

    // Convert 'amount' from 'fromCurrency' to USD, then from USD to 'toCurrency'
    const amountInUSD = amt / rateFromUSD;
    const convertedAmount = amountInUSD * rateToUSD;
    const effectiveRate = rateToUSD / rateFromUSD;
    
    setResult({
      fromCurrency,
      toCurrency,
      amount: amt,
      convertedAmount: parseFloat(convertedAmount.toFixed(4)), // typically 4 decimal places for rates
      rateUsed: parseFloat(effectiveRate.toFixed(6)),
    });
  };
  
  const swapCurrencies = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
    setResult(null); // Reset result on swap
  };

  const resetCalculator = () => {
    setAmount("1");
    setFromCurrency("USD");
    setToCurrency("INR");
    setResult(null);
    setError(null);
  };
  
  useEffect(() => {
    // Auto-convert on initial load or when currencies/amount change if inputs are valid
    if (isClient && amount && fromCurrency && toCurrency) {
        const amt = parseFloat(amount);
        if (!isNaN(amt) && amt >=0) {
             convertCurrency();
        } else {
            setResult(null); // Clear result if amount is invalid
        }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isClient, amount, fromCurrency, toCurrency]); // Deliberately not including convertCurrency to avoid infinite loops if not careful

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-primary/20">
      <CardContent className="p-6 space-y-6">
        <div className="p-2 text-xs text-center text-muted-foreground bg-muted/50 rounded-md">
            Note: This converter uses MOCK exchange rates for demonstration. For real-world conversions, an API integration is needed.
        </div>
        <div className="space-y-2">
          <Label htmlFor="amount" className="text-sm font-medium text-foreground">Amount</Label>
          <Input
            id="amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g., 100"
            className="h-12 text-base"
          />
        </div>

        <div className="flex items-center space-x-2 md:space-x-4">
          <div className="flex-1 space-y-1">
            <Label htmlFor="fromCurrency" className="text-sm font-medium text-foreground">From</Label>
            <Select value={fromCurrency} onValueChange={setFromCurrency}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {MOCK_CURRENCIES.map(curr => (
                  <SelectItem key={curr.code} value={curr.code}>
                    {curr.code} - {curr.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button variant="ghost" size="icon" onClick={swapCurrencies} className="mt-6 self-center hover:bg-primary/10" aria-label="Swap currencies">
            <ArrowRightLeft className="h-5 w-5 text-primary" />
          </Button>

          <div className="flex-1 space-y-1">
            <Label htmlFor="toCurrency" className="text-sm font-medium text-foreground">To</Label>
            <Select value={toCurrency} onValueChange={setToCurrency}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {MOCK_CURRENCIES.map(curr => (
                  <SelectItem key={curr.code} value={curr.code}>
                    {curr.code} - {curr.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {result && !error && (
          <div className="space-y-3 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center">Conversion Result</h3>
            <p className="text-3xl md:text-4xl font-bold text-center text-foreground" style={{fontFamily: 'var(--font-code)'}}>
              {result.convertedAmount.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:4})} {result.toCurrency}
            </p>
            <p className="text-sm text-muted-foreground text-center">
              {result.amount.toLocaleString()} {result.fromCurrency} = {result.convertedAmount.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:4})} {result.toCurrency}
            </p>
            <p className="text-xs text-muted-foreground text-center">
              1 {result.fromCurrency} ≈ {result.rateUsed.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:6})} {result.toCurrency} (Mock Rate)
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={convertCurrency} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          <Repeat className="mr-2 h-4 w-4" /> Convert
        </Button>
      </CardFooter>
    </Card>
  );
}

    