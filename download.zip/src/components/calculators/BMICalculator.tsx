
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, ScaleIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BMIResult {
  bmi: number;
  category: string;
  color: string;
}

const BMICategories = {
  underweight: { label: "Underweight", color: "text-blue-500", range: "< 18.5" },
  normal: { label: "Normal weight", color: "text-green-500", range: "18.5 – 24.9" },
  overweight: { label: "Overweight", color: "text-yellow-500", range: "25 – 29.9" },
  obese1: { label: "Obesity Class I", color: "text-orange-500", range: "30 – 34.9" },
  obese2: { label: "Obesity Class II", color: "text-red-500", range: "35 – 39.9" },
  obese3: { label: "Obesity Class III", color: "text-red-700", range: "≥ 40" },
};

export function BMICalculator() {
  const [height, setHeight] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [heightUnit, setHeightUnit] = useState<"cm" | "ft">("cm");
  const [feet, setFeet] = useState<string>("");
  const [inches, setInches] = useState<string>("");
  const [weightUnit, setWeightUnit] = useState<"kg" | "lbs">("kg");
  const [result, setResult] = useState<BMIResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateBMI = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    let heightInMeters: number;
    const weightInKg = parseFloat(weight);

    if (heightUnit === "cm") {
      const hCm = parseFloat(height);
      if (isNaN(hCm) || hCm <= 0) {
        setError("Please enter a valid height in cm.");
        return;
      }
      heightInMeters = hCm / 100;
    } else { // ft/in
      const hFt = parseFloat(feet);
      const hIn = parseFloat(inches) || 0; // Inches can be 0
      if (isNaN(hFt) || hFt < 0 || isNaN(hIn) || hIn < 0 || (hFt === 0 && hIn === 0)) {
        setError("Please enter a valid height in feet and inches.");
        return;
      }
      heightInMeters = (hFt * 12 + hIn) * 0.0254;
    }

    if (isNaN(weightInKg) || weightInKg <= 0) {
      setError("Please enter a valid weight.");
      return;
    }

    const finalWeightKg = weightUnit === "lbs" ? weightInKg * 0.453592 : weightInKg;

    if (heightInMeters <= 0 || finalWeightKg <=0) {
        setError("Height and weight must be positive values.");
        return;
    }

    const bmi = finalWeightKg / (heightInMeters * heightInMeters);
    let category = "";
    let color = "";

    if (bmi < 18.5) {
      category = BMICategories.underweight.label;
      color = BMICategories.underweight.color;
    } else if (bmi < 25) {
      category = BMICategories.normal.label;
      color = BMICategories.normal.color;
    } else if (bmi < 30) {
      category = BMICategories.overweight.label;
      color = BMICategories.overweight.color;
    } else if (bmi < 35) {
      category = BMICategories.obese1.label;
      color = BMICategories.obese1.color;
    } else if (bmi < 40) {
      category = BMICategories.obese2.label;
      color = BMICategories.obese2.color;
    } else {
      category = BMICategories.obese3.label;
      color = BMICategories.obese3.color;
    }
    
    setResult({ bmi: parseFloat(bmi.toFixed(2)), category, color });
  };

  const resetCalculator = () => {
    setHeight("");
    setWeight("");
    setFeet("");
    setInches("");
    // setHeightUnit("cm"); // Keep user's unit preference
    // setWeightUnit("kg");
    setResult(null);
    setError(null);
  };
  
  const handleHeightUnitChange = (value: "cm" | "ft") => {
    setHeightUnit(value);
    setHeight(""); // Clear height input when unit changes
    setFeet("");
    setInches("");
    setResult(null);
    setError(null);
  };

  const handleWeightUnitChange = (value: "kg" | "lbs") => {
    setWeightUnit(value);
    setWeight(""); // Clear weight input when unit changes
    setResult(null);
    setError(null);
  };


  if (!isClient) {
    return null; 
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-primary/20">
      <CardContent className="p-6 space-y-6">
        <div className="space-y-4">
          <div>
            <Label className="block text-sm font-medium text-foreground mb-1">Height Unit</Label>
            <RadioGroup
              value={heightUnit}
              onValueChange={handleHeightUnitChange}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="cm" id="cm" />
                <Label htmlFor="cm">Centimeters (cm)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="ft" id="ft" />
                <Label htmlFor="ft">Feet & Inches (ft/in)</Label>
              </div>
            </RadioGroup>
          </div>

          {heightUnit === "cm" ? (
            <div>
              <Label htmlFor="height-cm" className="block text-sm font-medium text-foreground mb-1">Height (cm)</Label>
              <Input
                id="height-cm"
                type="number"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                placeholder="e.g., 170"
                className="h-12 text-base"
              />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="height-ft" className="block text-sm font-medium text-foreground mb-1">Feet (ft)</Label>
                <Input
                  id="height-ft"
                  type="number"
                  value={feet}
                  onChange={(e) => setFeet(e.target.value)}
                  placeholder="e.g., 5"
                  className="h-12 text-base"
                />
              </div>
              <div>
                <Label htmlFor="height-in" className="block text-sm font-medium text-foreground mb-1">Inches (in)</Label>
                <Input
                  id="height-in"
                  type="number"
                  value={inches}
                  onChange={(e) => setInches(e.target.value)}
                  placeholder="e.g., 7"
                  className="h-12 text-base"
                />
              </div>
            </div>
          )}
        </div>

        <div className="space-y-4">
           <div>
            <Label className="block text-sm font-medium text-foreground mb-1">Weight Unit</Label>
            <RadioGroup
              value={weightUnit}
              onValueChange={handleWeightUnitChange}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="kg" id="kg" />
                <Label htmlFor="kg">Kilograms (kg)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="lbs" id="lbs" />
                <Label htmlFor="lbs">Pounds (lbs)</Label>
              </div>
            </RadioGroup>
          </div>
          <div>
            <Label htmlFor="weight" className="block text-sm font-medium text-foreground mb-1">
              Weight ({weightUnit})
            </Label>
            <Input
              id="weight"
              type="number"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder={weightUnit === "kg" ? "e.g., 65" : "e.g., 143"}
              className="h-12 text-base"
            />
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {result && !error && (
          <div className="space-y-3 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center">Your BMI Result</h3>
            <p className="text-6xl font-bold text-center text-foreground" style={{ fontFamily: 'var(--font-code)' }}>
              {result.bmi}
            </p>
            <p className={cn("text-2xl font-medium text-center", result.color)}>
              {result.category}
            </p>
            <div className="pt-4">
                <h4 className="text-sm font-semibold text-muted-foreground text-center mb-2">BMI Categories:</h4>
                <ul className="text-xs text-muted-foreground space-y-1 text-center">
                    {Object.values(BMICategories).map(cat => (
                        <li key={cat.label}><span className={cat.color}>{cat.label}:</span> {cat.range}</li>
                    ))}
                </ul>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateBMI} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          <ScaleIcon className="mr-2 h-4 w-4" /> Calculate BMI
        </Button>
      </CardFooter>
    </Card>
  );
}

