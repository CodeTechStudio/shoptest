
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Percent } from 'lucide-react';

interface GSTResult {
  initialAmount: number;
  gstRate: number;
  gstAmount: number;
  netAmount: number; // Pre-GST amount
  grossAmount: number; // Post-GST amount (or initial if removing)
  calculationType: "add" | "remove";
}

const COMMON_GST_RATES = ["5", "12", "18", "28", "Custom"];

export function GSTCalculator() {
  const [amount, setAmount] = useState<string>("");
  const [gstRate, setGstRate] = useState<string>("18"); // Default to 18%
  const [customGstRate, setCustomGstRate] = useState<string>("");
  const [calculationType, setCalculationType] = useState<"add" | "remove">("add");
  const [result, setResult] = useState<GSTResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleGstRateChange = (value: string) => {
    setGstRate(value);
    if (value !== "Custom") {
        setCustomGstRate(""); // Clear custom rate if a predefined one is selected
    }
    setResult(null); // Reset result when rate changes
  };

  const calculateGST = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const initialAmt = parseFloat(amount);
    const currentGstRate = gstRate === "Custom" ? parseFloat(customGstRate) : parseFloat(gstRate);

    if (isNaN(initialAmt) || initialAmt <= 0) {
      setError("Please enter a valid amount.");
      return;
    }
    if (isNaN(currentGstRate) || currentGstRate < 0) {
      setError("Please enter a valid GST rate.");
      return;
    }

    let gstAmount = 0;
    let netAmount = 0;
    let grossAmount = 0;

    if (calculationType === "add") {
      // Initial amount is pre-GST, add GST to it
      netAmount = initialAmt;
      gstAmount = initialAmt * (currentGstRate / 100);
      grossAmount = initialAmt + gstAmount;
    } else { // remove GST
      // Initial amount is post-GST (inclusive), remove GST from it
      grossAmount = initialAmt;
      netAmount = initialAmt / (1 + (currentGstRate / 100));
      gstAmount = initialAmt - netAmount;
    }
    
    setResult({
      initialAmount: initialAmt,
      gstRate: currentGstRate,
      gstAmount: parseFloat(gstAmount.toFixed(2)),
      netAmount: parseFloat(netAmount.toFixed(2)),
      grossAmount: parseFloat(grossAmount.toFixed(2)),
      calculationType,
    });
  };

  const resetCalculator = () => {
    setAmount("");
    setGstRate("18");
    setCustomGstRate("");
    setCalculationType("add");
    setResult(null);
    setError(null);
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-primary/20">
      <CardContent className="p-6 space-y-6">
        <div className="space-y-2">
          <Label htmlFor="amount" className="text-sm font-medium text-foreground">Amount (₹)</Label>
          <Input
            id="amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g., 1000"
            className="h-12 text-base"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm font-medium text-foreground">Calculation Type</Label>
          <RadioGroup
            value={calculationType}
            onValueChange={(value: "add" | "remove") => {
                setCalculationType(value);
                setResult(null);
            }}
            className="flex space-x-4"
          >
            <div className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50 cursor-pointer flex-1 justify-center">
              <RadioGroupItem value="add" id="addGst" />
              <Label htmlFor="addGst" className="cursor-pointer">Add GST</Label>
            </div>
            <div className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50 cursor-pointer flex-1 justify-center">
              <RadioGroupItem value="remove" id="removeGst" />
              <Label htmlFor="removeGst" className="cursor-pointer">Remove GST</Label>
            </div>
          </RadioGroup>
          <p className="text-xs text-muted-foreground px-1">
            {calculationType === 'add' 
                ? "Calculates GST on top of the entered amount." 
                : "Calculates GST included in the entered amount."}
          </p>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="gstRate" className="text-sm font-medium text-foreground">GST Rate (%)</Label>
          <div className="flex items-center gap-3">
            <Select value={gstRate} onValueChange={handleGstRateChange}>
              <SelectTrigger className="h-12 text-base flex-grow">
                <SelectValue placeholder="Select GST Rate" />
              </SelectTrigger>
              <SelectContent>
                {COMMON_GST_RATES.map(rate => (
                  <SelectItem key={rate} value={rate}>
                    {rate === "Custom" ? "Custom Rate" : `${rate}%`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {gstRate === "Custom" && (
              <Input
                type="number"
                value={customGstRate}
                onChange={(e) => {
                    setCustomGstRate(e.target.value);
                    setResult(null);
                }}
                placeholder="Custom %"
                className="h-12 text-base w-32"
              />
            )}
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {result && !error && (
          <div className="space-y-4 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center">GST Calculation Result</h3>
            <div className="space-y-2 text-lg">
                <div className="flex justify-between">
                    <span className="text-muted-foreground">
                        {result.calculationType === 'add' ? 'Original Amount:' : 'Net Amount (Pre-GST):'}
                    </span>
                    <span className="font-medium text-foreground">₹{result.netAmount.toLocaleString()}</span>
                </div>
                 <div className="flex justify-between">
                    <span className="text-muted-foreground">GST Rate:</span>
                    <span className="font-medium text-foreground">{result.gstRate}%</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-muted-foreground">GST Amount:</span>
                    <span className="font-medium text-foreground">₹{result.gstAmount.toLocaleString()}</span>
                </div>
                <hr className="my-2 border-border/50"/>
                <div className="flex justify-between font-bold text-xl">
                    <span className="text-primary">
                        {result.calculationType === 'add' ? 'Gross Amount (Post-GST):' : 'Original Amount (Inc. GST):'}
                    </span>
                    <span className="text-primary">₹{result.grossAmount.toLocaleString()}</span>
                </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateGST} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          <Percent className="mr-2 h-4 w-4" /> Calculate GST
        </Button>
      </CardFooter>
    </Card>
  );
}

    