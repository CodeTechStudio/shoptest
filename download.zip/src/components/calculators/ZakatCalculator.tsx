
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RefreshCw, Coins, AlertTriangle } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface ZakatResult {
  totalZakatableAssets: number;
  nisabMet: boolean;
  zakatDue: number;
}

export function ZakatCalculator() {
  const [cash, setCash] = useState<string>("");
  const [goldValue, setGoldValue] = useState<string>("");
  const [silverValue, setSilverValue] = useState<string>("");
  const [businessAssets, setBusinessAssets] = useState<string>("");
  const [sharesInvestments, setSharesInvestments] = useState<string>("");
  const [liabilities, setLiabilities] = useState<string>("");
  const [nisabThreshold, setNisabThreshold] = useState<string>("");

  const [result, setResult] = useState<ZakatResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const parseInput = (value: string): number => {
    const parsed = parseFloat(value);
    return isNaN(parsed) || parsed < 0 ? 0 : parsed;
  };

  const calculateZakat = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const numNisabThreshold = parseFloat(nisabThreshold);
    if (isNaN(numNisabThreshold) || numNisabThreshold <= 0) {
      setError("Please enter a valid Nisab threshold amount.");
      return;
    }
    
    const numCash = parseInput(cash);
    const numGoldValue = parseInput(goldValue);
    const numSilverValue = parseInput(silverValue);
    const numBusinessAssets = parseInput(businessAssets);
    const numSharesInvestments = parseInput(sharesInvestments);
    const numLiabilities = parseInput(liabilities);

    const totalAssets = numCash + numGoldValue + numSilverValue + numBusinessAssets + numSharesInvestments;
    const totalZakatableAssets = totalAssets - numLiabilities;

    if (totalZakatableAssets < 0) {
        setError("Total zakatable assets cannot be negative. Please check your liabilities.");
        setResult({ totalZakatableAssets: 0, nisabMet: false, zakatDue: 0});
        return;
    }

    const nisabMet = totalZakatableAssets >= numNisabThreshold;
    const zakatDue = nisabMet ? totalZakatableAssets * 0.025 : 0;

    setResult({
      totalZakatableAssets: parseFloat(totalZakatableAssets.toFixed(2)),
      nisabMet,
      zakatDue: parseFloat(zakatDue.toFixed(2)),
    });
  };

  const resetCalculator = () => {
    setCash("");
    setGoldValue("");
    setSilverValue("");
    setBusinessAssets("");
    setSharesInvestments("");
    setLiabilities("");
    setNisabThreshold("");
    setResult(null);
    setError(null);
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-xl mx-auto shadow-lg border-primary/20">
      <CardHeader>
         <CardTitle className="text-2xl font-semibold text-primary flex items-center">
            <Coins className="mr-2 h-7 w-7" /> Zakat Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <Accordion type="multiple" defaultValue={['item-1', 'item-2']} className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger className="text-lg font-medium text-foreground">Assets</AccordionTrigger>
            <AccordionContent className="space-y-4 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="cash" className="text-sm font-medium">Cash & Bank Balances</Label>
                  <Input id="cash" type="number" value={cash} onChange={(e) => setCash(e.target.value)} placeholder="e.g., 50000" className="h-11"/>
                </div>
                <div>
                  <Label htmlFor="goldValue" className="text-sm font-medium">Total Value of Gold Owned</Label>
                  <Input id="goldValue" type="number" value={goldValue} onChange={(e) => setGoldValue(e.target.value)} placeholder="e.g., 200000" className="h-11"/>
                </div>
                <div>
                  <Label htmlFor="silverValue" className="text-sm font-medium">Total Value of Silver Owned</Label>
                  <Input id="silverValue" type="number" value={silverValue} onChange={(e) => setSilverValue(e.target.value)} placeholder="e.g., 10000" className="h-11"/>
                </div>
                <div>
                  <Label htmlFor="businessAssets" className="text-sm font-medium">Value of Business Goods/Stock</Label>
                  <Input id="businessAssets" type="number" value={businessAssets} onChange={(e) => setBusinessAssets(e.target.value)} placeholder="e.g., 150000" className="h-11"/>
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="sharesInvestments" className="text-sm font-medium">Value of Shares & Investments (Zakatable portion)</Label>
                  <Input id="sharesInvestments" type="number" value={sharesInvestments} onChange={(e) => setSharesInvestments(e.target.value)} placeholder="e.g., 75000" className="h-11"/>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
          <AccordionItem value="item-2">
            <AccordionTrigger className="text-lg font-medium text-foreground">Liabilities & Nisab</AccordionTrigger>
            <AccordionContent className="space-y-4 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="liabilities" className="text-sm font-medium">Short-term Liabilities (Deductible)</Label>
                  <Input id="liabilities" type="number" value={liabilities} onChange={(e) => setLiabilities(e.target.value)} placeholder="e.g., 20000" className="h-11"/>
                </div>
                <div>
                  <Label htmlFor="nisabThreshold" className="text-sm font-medium">Nisab Threshold Amount</Label>
                  <Input id="nisabThreshold" type="number" value={nisabThreshold} onChange={(e) => setNisabThreshold(e.target.value)} placeholder="Value of 85g gold or 595g silver" className="h-11"/>
                   <p className="text-xs text-muted-foreground mt-1">e.g., Current market value of 595g silver.</p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2" /> {error}
          </p>
        )}

        {result && !error && (
          <div className="space-y-3 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-xl font-semibold text-primary text-center">Zakat Calculation</h3>
            <div className="flex justify-between text-lg">
              <span className="text-muted-foreground">Total Zakatable Assets:</span>
              <span className="font-medium text-foreground">₹{result.totalZakatableAssets.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-lg">
              <span className="text-muted-foreground">Nisab Met:</span>
              <span className={`font-medium ${result.nisabMet ? 'text-green-600' : 'text-red-600'}`}>
                {result.nisabMet ? 'Yes' : 'No'}
              </span>
            </div>
            <hr className="my-2 border-border/50"/>
            <div className="flex justify-between font-bold text-2xl">
              <span className="text-primary">Zakat Due:</span>
              <span className="text-primary">₹{result.zakatDue.toLocaleString()}</span>
            </div>
            {!result.nisabMet && result.totalZakatableAssets > 0 && (
                <p className="text-sm text-center text-muted-foreground pt-2">
                    Your Zakatable assets are below the Nisab threshold. No Zakat is due.
                </p>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateZakat} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          Calculate Zakat
        </Button>
      </CardFooter>
    </Card>
  );
}
