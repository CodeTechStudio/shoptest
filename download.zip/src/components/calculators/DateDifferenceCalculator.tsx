
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { CalendarIcon, RefreshCw, ArrowRightLeft } from 'lucide-react';
import { 
  format, 
  differenceInYears, 
  differenceInMonths, 
  differenceInDays, 
  addYears, 
  addMonths as addMonthsDateFns, 
  isValid,
  isAfter
} from 'date-fns';

interface DateDifferenceResult {
  years: number;
  months: number;
  days: number;
  totalDays: number;
}

export function DateDifferenceCalculator() {
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [result, setResult] = useState<DateDifferenceResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateDifference = () => {
    if (!isClient) return;
    if (!startDate || !isValid(startDate)) {
      setError("Please select a valid start date.");
      setResult(null);
      return;
    }
    if (!endDate || !isValid(endDate)) {
      setError("Please select a valid end date.");
      setResult(null);
      return;
    }

    if (isAfter(startDate, endDate)) {
      setError("Start date cannot be after end date.");
      setResult(null);
      return;
    }
    setError(null);

    const totalDays = differenceInDays(endDate, startDate);
    const years = differenceInYears(endDate, startDate);
    const dateAfterYears = addYears(startDate, years);
    const months = differenceInMonths(endDate, dateAfterYears);
    const dateAfterYearsAndMonths = addMonthsDateFns(dateAfterYears, months);
    const days = differenceInDays(endDate, dateAfterYearsAndMonths);
    
    setResult({ years, months, days, totalDays });
  };

  const resetCalculator = () => {
    setStartDate(undefined);
    setEndDate(undefined);
    setResult(null);
    setError(null);
  };

  if (!isClient) {
    return null; 
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-primary/20">
      <CardContent className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
          <div>
            <Label htmlFor="start-date-picker" className="block text-sm font-medium text-foreground mb-1">
              Start Date
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="start-date-picker"
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal h-12 text-base border-input hover:bg-accent/50",
                    !startDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-5 w-5 text-primary" />
                  {startDate ? format(startDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={startDate}
                  onSelect={(date) => { setStartDate(date); setResult(null); setError(null);}}
                  initialFocus
                  captionLayout="dropdown-buttons"
                  fromYear={1900}
                  toYear={new Date().getFullYear() + 50}
                />
              </PopoverContent>
            </Popover>
          </div>
          <div>
            <Label htmlFor="end-date-picker" className="block text-sm font-medium text-foreground mb-1">
              End Date
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="end-date-picker"
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal h-12 text-base border-input hover:bg-accent/50",
                    !endDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-5 w-5 text-primary" />
                  {endDate ? format(endDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={endDate}
                  onSelect={(date) => { setEndDate(date); setResult(null); setError(null);}}
                  initialFocus
                  captionLayout="dropdown-buttons"
                  fromYear={1900}
                  toYear={new Date().getFullYear() + 50}
                  disabled={(date) => startDate ? isAfter(startDate, date) : false}
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {result && !error && (
          <div className="space-y-4 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center mb-4">Difference</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center mb-4">
              <div>
                <p className="text-3xl md:text-4xl font-bold text-foreground">{result.years}</p>
                <p className="text-sm text-muted-foreground">Years</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold text-foreground">{result.months}</p>
                <p className="text-sm text-muted-foreground">Months</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold text-foreground">{result.days}</p>
                <p className="text-sm text-muted-foreground">Days</p>
              </div>
            </div>
            <div className="text-center pt-4 border-t mt-4 border-border/50">
              <p className="text-lg font-medium text-foreground">
                Total Difference in Days
              </p>
              <p className="text-3xl font-bold text-accent mt-1">
                {result.totalDays} day{result.totalDays !== 1 ? 's' : ''}
              </p>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateDifference} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          <ArrowRightLeft className="mr-2 h-4 w-4" /> Calculate Difference
        </Button>
      </CardFooter>
    </Card>
  );
}

