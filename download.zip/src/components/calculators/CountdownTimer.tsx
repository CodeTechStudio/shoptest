
"use client";

import { useState, useEffect, FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { CalendarIcon, RefreshCw, TimerIcon, Play, Pause, RotateCcw } from 'lucide-react';
import { format, differenceInSeconds, isValid, isFuture, set } from 'date-fns';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function CountdownTimer() {
  const [targetDate, setTargetDate] = useState<Date | undefined>(undefined);
  const [targetTime, setTargetTime] = useState<string>("00:00"); // HH:MM format
  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [intervalId, setIntervalId] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateTimeLeft = () => {
    if (!targetDate || !isValid(targetDate)) {
      setError("Please select a valid target date.");
      setIsRunning(false);
      return null;
    }

    const [hours, minutes] = targetTime.split(':').map(Number);
    if (isNaN(hours) || hours < 0 || hours > 23 || isNaN(minutes) || minutes < 0 || minutes > 59) {
        setError("Please enter a valid time (HH:MM).");
        setIsRunning(false);
        return null;
    }

    const fullTargetDateTime = set(targetDate, { hours, minutes, seconds: 0, milliseconds: 0 });

    if (!isFuture(fullTargetDateTime)) {
      setError("Target date and time must be in the future.");
      setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      setIsRunning(false);
      return { days: 0, hours: 0, minutes: 0, seconds: 0 };
    }
    setError(null);

    const now = new Date();
    const totalSeconds = differenceInSeconds(fullTargetDateTime, now);

    if (totalSeconds <= 0) {
      setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      setIsRunning(false);
      if(intervalId) clearInterval(intervalId);
      return { days: 0, hours: 0, minutes: 0, seconds: 0 };
    }

    const days = Math.floor(totalSeconds / (3600 * 24));
    const hoursRem = Math.floor((totalSeconds % (3600 * 24)) / 3600);
    const minutesRem = Math.floor((totalSeconds % 3600) / 60);
    const secondsRem = Math.floor(totalSeconds % 60);

    return { days, hours: hoursRem, minutes: minutesRem, seconds: secondsRem };
  };

  useEffect(() => {
    if (isRunning) {
      const id = setInterval(() => {
        const newTimeLeft = calculateTimeLeft();
        if (newTimeLeft) {
          setTimeLeft(newTimeLeft);
          if (newTimeLeft.days === 0 && newTimeLeft.hours === 0 && newTimeLeft.minutes === 0 && newTimeLeft.seconds === 0) {
            setIsRunning(false);
            if(intervalId) clearInterval(intervalId);
          }
        } else {
             setIsRunning(false); // Stop if date becomes invalid or past
             if(intervalId) clearInterval(intervalId);
        }
      }, 1000);
      setIntervalId(id);
      return () => clearInterval(id);
    } else {
      if (intervalId) {
        clearInterval(intervalId);
        setIntervalId(null);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRunning, targetDate, targetTime]);

  const handleStartPause = () => {
    if (!isRunning) {
      const initialTimeLeft = calculateTimeLeft();
      if (initialTimeLeft) {
        setTimeLeft(initialTimeLeft);
        setIsRunning(true);
      }
    } else {
      setIsRunning(false);
    }
  };

  const resetTimer = () => {
    setTargetDate(undefined);
    setTargetTime("00:00");
    setTimeLeft(null);
    setError(null);
    setIsRunning(false);
    if (intervalId) clearInterval(intervalId);
    setIntervalId(null);
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-primary/20">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-primary flex items-center">
          <TimerIcon className="mr-2 h-7 w-7" /> Countdown Timer
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
          <div>
            <Label htmlFor="target-date-picker" className="block text-sm font-medium text-foreground mb-1">
              Target Date
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  id="target-date-picker"
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal h-12 text-base border-input hover:bg-accent/50",
                    !targetDate && "text-muted-foreground"
                  )}
                  disabled={isRunning}
                >
                  <CalendarIcon className="mr-2 h-5 w-5 text-primary" />
                  {targetDate ? format(targetDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={targetDate}
                  onSelect={(date) => { setTargetDate(date); setError(null); setTimeLeft(null); }}
                  disabled={(date) => date < new Date(new Date().setHours(0,0,0,0)) || isRunning} // Disable past dates
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          <div>
            <Label htmlFor="target-time" className="block text-sm font-medium text-foreground mb-1">
              Target Time (HH:MM)
            </Label>
            <Input
              id="target-time"
              type="time"
              value={targetTime}
              onChange={(e) => { setTargetTime(e.target.value); setError(null); setTimeLeft(null);}}
              className="h-12 text-base"
              disabled={isRunning}
            />
          </div>
        </div>

        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md animate-in fade-in-0 zoom-in-95">{error}</p>
        )}

        {timeLeft && (
          <div className="space-y-4 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-2xl font-semibold text-primary text-center mb-4">Time Remaining</h3>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div>
                <p className="text-4xl font-bold text-foreground tabular-nums">{String(timeLeft.days).padStart(2, '0')}</p>
                <p className="text-xs text-muted-foreground">DAYS</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-foreground tabular-nums">{String(timeLeft.hours).padStart(2, '0')}</p>
                <p className="text-xs text-muted-foreground">HOURS</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-foreground tabular-nums">{String(timeLeft.minutes).padStart(2, '0')}</p>
                <p className="text-xs text-muted-foreground">MINUTES</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-foreground tabular-nums">{String(timeLeft.seconds).padStart(2, '0')}</p>
                <p className="text-xs text-muted-foreground">SECONDS</p>
              </div>
            </div>
             {timeLeft.days === 0 && timeLeft.hours === 0 && timeLeft.minutes === 0 && timeLeft.seconds === 0 && !error && (
                <p className="text-center text-accent font-semibold text-lg pt-4">Countdown Finished!</p>
             )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetTimer} className="w-auto text-sm">
          <RotateCcw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={handleStartPause} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm" disabled={!targetDate}>
          {isRunning ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
          {isRunning ? 'Pause' : 'Start'}
        </Button>
      </CardFooter>
    </Card>
  );
}

    