
"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RefreshCw, ShieldCheck, AlertTriangle, Percent } from 'lucide-react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

interface MurabahaResult {
  totalProfit: number;
  sellingPrice: number;
  monthlyInstallment: number;
}

export function MurabahaProfitCalculator() {
  const [assetCost, setAssetCost] = useState<string>("");
  const [profitMargin, setProfitMargin] = useState<string>(""); // Percentage
  const [tenure, setTenure] = useState<string>(""); // In years
  const [tenureUnit, setTenureUnit] = useState<"years" | "months">("years");


  const [result, setResult] = useState<MurabahaResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const calculateMurabaha = () => {
    if (!isClient) return;
    setError(null);
    setResult(null);

    const P = parseFloat(assetCost); // Asset Cost Price
    const R = parseFloat(profitMargin); // Profit Percentage
    let T_months = parseInt(tenure, 10); // Tenure 

    if (isNaN(P) || P <= 0) {
      setError("Please enter a valid asset cost price.");
      return;
    }
    if (isNaN(R) || R < 0) { // Profit can be 0
      setError("Please enter a valid profit margin percentage.");
      return;
    }
    if (isNaN(T_months) || T_months <= 0) {
      setError("Please enter a valid tenure.");
      return;
    }

    if (tenureUnit === "years") {
        T_months = T_months * 12;
    }
    if (T_months <= 0) {
        setError("Tenure in months must be greater than zero.");
        return;
    }


    const totalProfit = P * (R / 100);
    const sellingPrice = P + totalProfit;
    const monthlyInstallment = sellingPrice / T_months;

    setResult({
      totalProfit: parseFloat(totalProfit.toFixed(2)),
      sellingPrice: parseFloat(sellingPrice.toFixed(2)),
      monthlyInstallment: parseFloat(monthlyInstallment.toFixed(2)),
    });
  };

  const resetCalculator = () => {
    setAssetCost("");
    setProfitMargin("");
    setTenure("");
    setTenureUnit("years");
    setResult(null);
    setError(null);
  };

  if (!isClient) {
    return <div className="flex justify-center items-center h-64"><RefreshCw className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-primary/20">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-primary flex items-center">
            <ShieldCheck className="mr-2 h-7 w-7" /> Murabaha (Cost-Plus Profit) Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-2">
          <Label htmlFor="assetCost" className="text-sm font-medium text-foreground">Asset Cost Price (₹)</Label>
          <Input
            id="assetCost"
            type="number"
            value={assetCost}
            onChange={(e) => setAssetCost(e.target.value)}
            placeholder="e.g., 100000"
            className="h-12 text-base"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="profitMargin" className="text-sm font-medium text-foreground">Profit Margin (%)</Label>
          <div className="relative">
            <Input
                id="profitMargin"
                type="number"
                value={profitMargin}
                onChange={(e) => setProfitMargin(e.target.value)}
                placeholder="e.g., 10"
                className="h-12 text-base pr-10"
            />
            <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          </div>
        </div>
        <div className="space-y-2">
            <Label htmlFor="tenure" className="text-sm font-medium text-foreground">Financing Tenure</Label>
            <div className="flex items-center gap-3">
                <Input
                id="tenure"
                type="number"
                value={tenure}
                onChange={(e) => setTenure(e.target.value)}
                placeholder={tenureUnit === "years" ? "e.g., 2" : "e.g., 24"}
                className="h-12 text-base flex-grow"
                />
                <RadioGroup
                value={tenureUnit}
                onValueChange={(value: "years" | "months") => {
                    setTenureUnit(value);
                    setResult(null); 
                }}
                className="flex"
                >
                <div className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50 cursor-pointer">
                    <RadioGroupItem value="years" id="years" />
                    <Label htmlFor="years" className="cursor-pointer text-sm">Years</Label>
                </div>
                <div className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50 cursor-pointer">
                    <RadioGroupItem value="months" id="months" />
                    <Label htmlFor="months" className="cursor-pointer text-sm">Months</Label>
                </div>
                </RadioGroup>
            </div>
        </div>


        {error && (
          <p className="text-sm text-destructive bg-destructive/10 p-3 rounded-md flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2" /> {error}
          </p>
        )}

        {result && !error && (
          <div className="space-y-4 p-6 border rounded-lg bg-secondary/30 dark:bg-card shadow-inner animate-in fade-in-0 zoom-in-95">
            <h3 className="text-xl font-semibold text-primary text-center">Financing Details</h3>
            <div className="space-y-2 text-lg">
                 <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Profit:</span>
                    <span className="font-medium text-foreground">₹{result.totalProfit.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Selling Price:</span>
                    <span className="font-medium text-foreground">₹{result.sellingPrice.toLocaleString()}</span>
                </div>
                <hr className="my-2 border-border/50"/>
                <div className="flex justify-between font-bold text-xl">
                    <span className="text-primary">Monthly Installment:</span>
                    <span className="text-primary">₹{result.monthlyInstallment.toLocaleString()}</span>
                </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between p-6 bg-muted/30 dark:bg-muted/20 border-t">
        <Button variant="outline" onClick={resetCalculator} className="w-auto text-sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Reset
        </Button>
        <Button onClick={calculateMurabaha} className="w-auto bg-primary hover:bg-primary/90 text-primary-foreground text-sm">
          Calculate
        </Button>
      </CardFooter>
    </Card>
  );
}
