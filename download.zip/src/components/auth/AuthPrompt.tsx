
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogIn, UserPlus, AlertTriangle } from "lucide-react";
import { LoginModal } from "./LoginModal";
import { RegisterModal } from "./RegisterModal";
import type { Calculator } from "@/types/calculators";

interface AuthPromptProps {
  calculatorName: string;
  onAuthSuccess: () => void; // Callback to re-check auth status after successful login/register
}

export function AuthPrompt({ calculatorName, onAuthSuccess }: AuthPromptProps) {
  return (
    <Card className="w-full max-w-lg mx-auto my-10 shadow-xl border-destructive/20">
      <CardHeader className="text-center">
        <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <CardTitle className="text-2xl font-bold text-destructive">Access Restricted</CardTitle>
        <CardDescription className="text-lg text-muted-foreground mt-2">
          You need to be logged in to use the <span className="font-semibold text-primary">{calculatorName}</span>.
        </CardDescription>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <p className="text-muted-foreground">Please log in or create an account to continue.</p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <LoginModal 
            trigger={<Button className="w-full sm:w-auto"><LogIn className="mr-2 h-4 w-4"/> Login</Button>}
            onLoginSuccess={onAuthSuccess} 
          />
          <RegisterModal 
            trigger={<Button variant="outline" className="w-full sm:w-auto"><UserPlus className="mr-2 h-4 w-4"/> Register</Button>}
            onRegisterSuccess={onAuthSuccess}
          />
        </div>
      </CardContent>
    </Card>
  );
}
