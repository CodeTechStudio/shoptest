import { config } from 'dotenv';
config();

import '@/ai/flows/calculator-suggestion.ts';