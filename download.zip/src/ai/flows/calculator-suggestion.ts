
'use server';

/**
 * @fileOverview This file defines a Genkit flow for suggesting calculators based on a user's natural language query.
 *
 * - calculatorSuggestion - A function that takes a user query and returns a suggested calculator.
 * - CalculatorSuggestionInput - The input type for the calculatorSuggestion function.
 * - CalculatorSuggestionOutput - The return type for the calculatorSuggestion function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CalculatorSuggestionInputSchema = z.object({
  query: z.string().describe('The user query in natural language.'),
});
export type CalculatorSuggestionInput = z.infer<typeof CalculatorSuggestionInputSchema>;

const CalculatorSuggestionOutputSchema = z.object({
  calculatorName: z.string().describe('The name of the suggested calculator.'),
  reason: z.string().describe('The reason why this calculator is suggested.'),
});
export type CalculatorSuggestionOutput = z.infer<typeof CalculatorSuggestionOutputSchema>;

export async function calculatorSuggestion(input: CalculatorSuggestionInput): Promise<CalculatorSuggestionOutput> {
  return calculatorSuggestionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'calculatorSuggestionPrompt',
  input: {schema: CalculatorSuggestionInputSchema},
  output: {schema: CalculatorSuggestionOutputSchema},
  prompt: `You are a calculator suggestion assistant. A user will provide a query in natural language, and you will suggest the most appropriate calculator for their needs.

Given the following user query:
{{query}}

Please suggest a calculator from the list below:
- Standard Calculator
- Age Calculator
- Date Difference
- Countdown Timer
- EMI Calculator
- SIP Calculator
- GST Calculator
- Currency Converter
- BMI Calculator
- Zakat Calculator
- Qurbani Calculator
- Missed Fast Calculator
- Islamic Loan Profit Calculator

Return the calculatorName and the reason for choosing the suggested calculator.
`,
});

const calculatorSuggestionFlow = ai.defineFlow(
  {
    name: 'calculatorSuggestionFlow',
    inputSchema: CalculatorSuggestionInputSchema,
    outputSchema: CalculatorSuggestionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

    
